var require = meteorInstall({"lib":{"Collections":{"Chat.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/Chat.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Chat = new Mongo.Collection('chat');                                                                              // 1
Chat.allow({                                                                                                      // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    message: function (postAttributes) {                                                                          // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date(),                                                                                // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Chat.insert(post);                                                                           // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    },                                                                                                            // 20
    bloquer_user: function (postAttributes) {                                                                     // 23
        var post = _.extend(postAttributes, {                                                                     // 24
            date: new Date()                                                                                      // 25
        });                                                                                                       // 24
                                                                                                                  //
        var postId = UserBloquer.insert(post);                                                                    // 27
        return {                                                                                                  // 28
            _id: postId                                                                                           // 29
        };                                                                                                        // 28
    }                                                                                                             // 31
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserBloquer.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/UserBloquer.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer = new Mongo.Collection('userBloquer');                                                                // 1
UserBloquer.allow({                                                                                               // 3
  update: function (userId) {                                                                                     // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId) {                                                                                     // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/alerte.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Alertes = new Mongo.Collection('alertes');                                                                        // 1
Alertes.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    alerteInsert: function (postAttributes) {                                                                     // 11
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            author_id: user._id,                                                                                  // 14
            author_name: user.username,                                                                           // 15
            gender: user.profile.gender,                                                                          // 16
            post_date: new Date()                                                                                 // 17
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 19
        return {                                                                                                  // 20
            _id: postId                                                                                           // 21
        };                                                                                                        // 20
    },                                                                                                            // 23
    alerteInsert1: function (postAttributes) {                                                                    // 25
        var user = Meteor.user();                                                                                 // 26
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 27
            author_id: user._id,                                                                                  // 28
            author_name: user.username,                                                                           // 29
            gender: user.profile.gender,                                                                          // 30
            post_date: new Date()                                                                                 // 31
        });                                                                                                       // 27
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 33
        return {                                                                                                  // 34
            _id: postId                                                                                           // 35
        };                                                                                                        // 34
    }                                                                                                             // 37
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"avertissement.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/avertissement.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Avertissement = new Mongo.Collection('avertissement_user');                                                       // 1
Avertissement.allow({                                                                                             // 3
  insert: function (userId, post) {                                                                               // 4
    return true;                                                                                                  // 4
  },                                                                                                              // 4
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comment.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/comment.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Comments = new Mongo.Collection('comments');                                                                      // 1
Meteor.methods({                                                                                                  // 4
  commentInsert: function (commentAttributes) {                                                                   // 5
    /*check(this.userId, String);                                                                                 // 6
    check(commentAttributes, {                                                                                    //
      postId: String,                                                                                             //
      body: String                                                                                                //
    });*/var user = Meteor.user();                                                                                //
    var post = Posts.findOne(commentAttributes.postId);                                                           // 12
    if (!post) throw new Meteor.Error('invalid-comment', 'Vous devez commenter sur un post');                     // 13
    comment = _.extend(commentAttributes, {                                                                       // 15
      userId: user._id,                                                                                           // 16
      gender: user.profile.gender,                                                                                // 17
      author: user.username,                                                                                      // 18
      submitted: new Date(),                                                                                      // 19
      upvoters: [],                                                                                               // 20
      votes: 0,                                                                                                   // 21
      nbr_votant: 0                                                                                               // 22
    }); // crée le commentaire et enregistre l'id                                                                 // 15
                                                                                                                  //
    comment._id = Comments.insert(comment); // crée maintenant une notification, informant l'utilisateur qu'il y a eu un commentaire
                                                                                                                  //
    createCommentNotification(comment);                                                                           // 27
    return comment._id;                                                                                           // 28
  },                                                                                                              // 29
  upvote: function (commentId) {                                                                                  // 31
    check(this.userId, String);                                                                                   // 32
    check(commentId, String);                                                                                     // 33
    var comment = Comments.findOne(commentId);                                                                    // 34
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 35
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 39
      $addToSet: {                                                                                                // 40
        upvoters: this.userId                                                                                     // 40
      },                                                                                                          // 40
      $inc: {                                                                                                     // 41
        votes: 1                                                                                                  // 41
      }                                                                                                           // 41
    });                                                                                                           // 39
    Comments.update(comment._id, {                                                                                // 43
      $inc: {                                                                                                     // 44
        nbr_votant: 1                                                                                             // 44
      }                                                                                                           // 44
    });                                                                                                           // 43
  },                                                                                                              // 46
  downvote: function (commentId) {                                                                                // 48
    check(this.userId, String);                                                                                   // 49
    check(commentId, String);                                                                                     // 50
    var comment = Comments.findOne(commentId);                                                                    // 51
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 52
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 56
      $addToSet: {                                                                                                // 57
        upvoters: this.userId                                                                                     // 57
      },                                                                                                          // 57
      $inc: {                                                                                                     // 58
        votes: -1                                                                                                 // 58
      }                                                                                                           // 58
    });                                                                                                           // 56
    Comments.update(comment._id, {                                                                                // 60
      $inc: {                                                                                                     // 61
        nbr_votant: 1                                                                                             // 61
      }                                                                                                           // 61
    });                                                                                                           // 60
  }                                                                                                               // 63
});                                                                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentaires.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/commentaires.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Commentaires = new Mongo.Collection('commentaires');                                                              // 1
Commentaires.allow({                                                                                              // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    AddComment: function (postAttributes) {                                                                       // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            date: new Date(),                                                                                     // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Commentaires.insert(post);                                                                   // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"conseilleres.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/conseilleres.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Conseilleres = new Mongo.Collection('conseilleres');                                                              // 1
Conseilleres.allow({                                                                                              // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  AddConseillere: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      user_id: user._id,                                                                                          // 13
      username: user.username,                                                                                    // 14
      gender: user.profile.gender,                                                                                // 15
      date: new Date(),                                                                                           // 16
      lastLogin: new Date()                                                                                       // 17
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Conseilleres.insert(post);                                                                       // 19
    return {                                                                                                      // 20
      _id: postId                                                                                                 // 21
    };                                                                                                            // 20
  }                                                                                                               // 23
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"contact_chat.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/contact_chat.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _objectDestructuringEmpty2 = require("babel-runtime/helpers/objectDestructuringEmpty");                       //
                                                                                                                  //
var _objectDestructuringEmpty3 = _interopRequireDefault(_objectDestructuringEmpty2);                              //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
ContactChat = new Mongo.Collection('contact_Chat');                                                               // 1
ContactChat.allow({                                                                                               // 3
  update: function () {                                                                                           // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (_ref) {                                                                                       // 6
    (0, _objectDestructuringEmpty3.default)(_ref);                                                                // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  contact_chat: function (postAttributes) {                                                                       // 10
    var post = _.extend(postAttributes, {                                                                         // 11
      date: new Date(),                                                                                           // 12
      last_message: ' ',                                                                                          // 13
      read: false                                                                                                 // 14
    });                                                                                                           // 11
                                                                                                                  //
    var postId = ContactChat.insert(post);                                                                        // 16
    return {                                                                                                      // 17
      _id: postId                                                                                                 // 18
    };                                                                                                            // 17
  }                                                                                                               // 20
});                                                                                                               // 9
Meteor.methods({                                                                                                  // 25
  update_active: function (postAttributes) {                                                                      // 26
    var userId = Meteor.userId();                                                                                 // 27
                                                                                                                  //
    if (postAttributes.id_from_active) {                                                                          // 28
      ContactChat.update({                                                                                        // 29
        from_id: userId                                                                                           // 29
      }, {                                                                                                        // 29
        $set: {                                                                                                   // 29
          "id_from_active": false                                                                                 // 29
        }                                                                                                         // 29
      }, {                                                                                                        // 29
        multi: true                                                                                               // 29
      });                                                                                                         // 29
      ContactChat.update({                                                                                        // 30
        _id: postAttributes._id                                                                                   // 30
      }, {                                                                                                        // 30
        $set: {                                                                                                   // 30
          "id_from_active": true                                                                                  // 30
        }                                                                                                         // 30
      });                                                                                                         // 30
    }                                                                                                             // 30
                                                                                                                  //
    if (postAttributes.id_to_active) {                                                                            // 32
      ContactChat.update({                                                                                        // 33
        to_id: userId                                                                                             // 33
      }, {                                                                                                        // 33
        $set: {                                                                                                   // 33
          "id_to_active": false                                                                                   // 33
        }                                                                                                         // 33
      }, {                                                                                                        // 33
        multi: true                                                                                               // 33
      });                                                                                                         // 33
      ContactChat.update({                                                                                        // 34
        _id: postAttributes._id                                                                                   // 34
      }, {                                                                                                        // 34
        $set: {                                                                                                   // 34
          "id_to_active": true                                                                                    // 34
        }                                                                                                         // 34
      });                                                                                                         // 34
    } //ContactChat.update({from_id : userId}, {$set:{ "active" : false }} );                                     // 34
    //ContactChat.update({to_id : userId}, {$set:{ "active" : false }} );                                         // 36
                                                                                                                  //
                                                                                                                  //
    ContactChat.update({                                                                                          // 37
      _id: postAttributes._id                                                                                     // 37
    }, {                                                                                                          // 37
      $set: {                                                                                                     // 37
        "active": true                                                                                            // 37
      }                                                                                                           // 37
    });                                                                                                           // 37
  }                                                                                                               // 38
});                                                                                                               // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"delete_alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/delete_alerte.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
DeleteAlertes = new Mongo.Collection('delete_alertes');                                                           // 1
DeleteAlertes.allow({                                                                                             // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    delete_alerte: function (postAttributes) {                                                                    // 10
        var post = _.extend(postAttributes, {});                                                                  // 11
                                                                                                                  //
        var postId = DeleteAlertes.insert(post);                                                                  // 14
        return {                                                                                                  // 15
            _id: postId                                                                                           // 16
        };                                                                                                        // 15
    }                                                                                                             // 18
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"friends.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/friends.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Friends = new Mongo.Collection('friends');                                                                        // 1
Friends.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    ami_accepte: function (postAttributes) {                                                                      // 10
        /*check(Meteor.userId(), String);                                                                         // 11
        check(postAttributes, {                                                                                   //
            post_title: String,                                                                                   //
            post_content: String,                                                                                 //
            categorie: String                                                                                     //
        });*/var user = Meteor.user();                                                                            //
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 18
            date: new Date()                                                                                      // 19
        });                                                                                                       // 18
                                                                                                                  //
        var postId = Friends.insert(post);                                                                        // 22
        return {                                                                                                  // 23
            _id: postId                                                                                           // 24
        };                                                                                                        // 23
    }                                                                                                             // 26
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"histoire.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/histoire.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Histoires = new Mongo.Collection('histoires');                                                                    // 1
Histoires.allow({                                                                                                 // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  histoireInsert: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      post_author: user._id,                                                                                      // 13
      author_name: user.username,                                                                                 // 14
      gender: user.profile.gender,                                                                                // 15
      post_date: new Date()                                                                                       // 16
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Histoires.insert(post);                                                                          // 18
    return {                                                                                                      // 19
      _id: postId                                                                                                 // 20
    };                                                                                                            // 19
  }                                                                                                               // 22
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages_signaler.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/messages_signaler.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Signaler = new Mongo.Collection('messages_signaler');                                                             // 1
Signaler.allow({                                                                                                  // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    signaler_message: function (postAttributes) {                                                                 // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = Signaler.insert(post);                                                                       // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/notifications.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Notifications = new Mongo.Collection('notifications');                                                            // 1
Notifications.allow({                                                                                             // 3
  update: function (userId, doc, fieldNames) {                                                                    // 4
    return ownsDocument(userId, doc) && fieldNames.length === 1 && fieldNames[0] === 'read';                      // 5
  }                                                                                                               // 7
});                                                                                                               // 3
                                                                                                                  //
createCommentNotification = function (comment) {                                                                  // 10
  var post = Posts.findOne(comment.postId);                                                                       // 11
                                                                                                                  //
  if (comment.userId !== post.post_author) {                                                                      // 12
    Notifications.insert({                                                                                        // 13
      userId: post.post_author,                                                                                   // 14
      postId: post._id,                                                                                           // 15
      commentId: comment._id,                                                                                     // 16
      commenterName: comment.author,                                                                              // 17
      read: false                                                                                                 // 18
    });                                                                                                           // 13
  }                                                                                                               // 20
};                                                                                                                // 21
                                                                                                                  //
createFriendsNotification = function (post) {                                                                     // 23
  Notifications.insert({                                                                                          // 24
    from_id: post.from_id,                                                                                        // 25
    to_id: post.to_id,                                                                                            // 26
    name_from_id: post.name_from_id,                                                                              // 27
    name_to_id: post.name_to_id,                                                                                  // 28
    date: post.date,                                                                                              // 29
    read: false                                                                                                   // 30
  });                                                                                                             // 24
};                                                                                                                // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"posts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/posts.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Posts = new Mongo.Collection('posts'); /*Posts.allow({                                                            // 1
                                         insert: function(userId, doc) {                                          //
                                           // autoriser les posts seulement si l'utilisateur est authentifié      //
                                           return !! userId;                                                      //
                                         }                                                                        //
                                        });*/                                                                     //
Posts.allow({                                                                                                     // 10
  update: function (userId, post) {                                                                               // 12
    return ownsDocument(userId, post);                                                                            // 12
  },                                                                                                              // 12
  remove: function (userId, post) {                                                                               // 13
    return ownsDocument(userId, post);                                                                            // 13
  }                                                                                                               // 13
});                                                                                                               // 10
Meteor.users.allow({                                                                                              // 16
  update: function (userId, post) {                                                                               // 17
    return true;                                                                                                  // 17
  }                                                                                                               // 17
}); /*var errors = validatePost(postAttributes);                                                                  // 16
        if (errors.post_title || errors.post_content)                                                             //
          throw new Meteor.Error('invalid-post', "You must set a title and URL for your post");*/                 //
Meteor.methods({                                                                                                  // 24
  postInsert: function (postAttributes) {                                                                         // 25
    /*check(Meteor.userId(), String);                                                                             // 26
    check(postAttributes, {                                                                                       //
        post_title: String,                                                                                       //
        post_content: String,                                                                                     //
        categorie: String                                                                                         //
    });*/var user = Meteor.user();                                                                                //
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 33
      post_author: user._id,                                                                                      // 34
      author_name: user.username,                                                                                 // 35
      gender: user.profile.gender,                                                                                // 36
      post_date: new Date(),                                                                                      // 37
      upvoters: [],                                                                                               // 38
      votes: 0                                                                                                    // 39
    });                                                                                                           // 33
                                                                                                                  //
    var postId = Posts.insert(post);                                                                              // 41
    return {                                                                                                      // 42
      _id: postId                                                                                                 // 43
    };                                                                                                            // 42
  },                                                                                                              // 45
  upvote1: function (postId) {                                                                                    // 47
    check(this.userId, String);                                                                                   // 48
    check(postId, String);                                                                                        // 49
    var post = Posts.findOne(postId);                                                                             // 50
    if (!post) throw new Meteor.Error('invalid', 'Post not found');                                               // 51
    if (_.include(post.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');    // 53
    Posts.update(post._id, {                                                                                      // 55
      $addToSet: {                                                                                                // 56
        upvoters: this.userId                                                                                     // 56
      },                                                                                                          // 56
      $inc: {                                                                                                     // 57
        votes: -1                                                                                                 // 57
      }                                                                                                           // 57
    });                                                                                                           // 55
  }                                                                                                               // 59
});                                                                                                               // 24
                                                                                                                  //
validatePost = function (post) {                                                                                  // 63
  var errors = {};                                                                                                // 64
  if (!post.post_title) errors.title = "Please fill in a headline";                                               // 65
  if (!post.content) errors.url = "Please fill in a URL";                                                         // 67
  return errors;                                                                                                  // 69
};                                                                                                                // 70
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/request.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Requests = new Mongo.Collection('requests');                                                                      // 1
Requests.allow({                                                                                                  // 3
    update: function () {                                                                                         // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function () {                                                                                         // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    demande_ami: function (postAttributes) {                                                                      // 10
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            date: new Date()                                                                                      // 14
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Requests.insert(post);                                                                       // 16
        createFriendsNotification(post);                                                                          // 17
        return {                                                                                                  // 18
            _id: postId                                                                                           // 19
        };                                                                                                        // 18
    },                                                                                                            // 21
    delete_request: function (postAttributes) {                                                                   // 23
        var user = Meteor.userId();                                                                               // 24
                                                                                                                  //
        var post = _.extend(postAttributes, {});                                                                  // 25
                                                                                                                  //
        Requests.remove({                                                                                         // 29
            "from_id": post.from_id,                                                                              // 29
            "to_id": user                                                                                         // 29
        });                                                                                                       // 29
        Requests.remove({                                                                                         // 30
            "from_id": user,                                                                                      // 30
            "to_id": post.from_id                                                                                 // 30
        });                                                                                                       // 30
    }                                                                                                             // 31
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/user.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Mongo = void 0;                                                                                               // 1
module.watch(require("meteor/mongo"), {                                                                           // 1
  Mongo: function (v) {                                                                                           // 1
    Mongo = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
Meteor.users.allow({                                                                                              // 2
  /*update: function(userId, post) { return ownsDocument(userId, post); },*/remove: function (userId) {           // 4
    return true;                                                                                                  // 5
  }                                                                                                               // 5
});                                                                                                               // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userBloquer_IP.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/userBloquer_IP.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer_IP = new Mongo.Collection('user_bloquer_IP');                                                         // 1
UserBloquer_IP.allow({                                                                                            // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    bloquerUser_IP: function (postAttributes) {                                                                   // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = UserBloquer_IP.insert(post);                                                                 // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"visites.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/visites.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Visites = new Mongo.Collection('visites');                                                                        // 1
Visites.allow({                                                                                                   // 3
    update: function (userId) {                                                                                   // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId) {                                                                                   // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    add_visites: function (postAttributes) {                                                                      // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date()                                                                                 // 12
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Visites.insert(post);                                                                        // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    }                                                                                                             // 20
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"permission.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/permission.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// check that the userId specified owns the documents                                                             // 1
ownsDocument = function (userId, doc) {                                                                           // 2
  //return doc && doc.userId === userId;                                                                          // 3
  return 1 === 1;                                                                                                 // 4
};                                                                                                                // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/router.js                                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Router.configure({                                                                                                // 1
  layoutTemplate: 'layout',                                                                                       // 2
  loadingTemplate: 'loading',                                                                                     // 3
  notFoundTemplate: 'notFound',                                                                                   // 4
  waitOn: function () {                                                                                           // 5
    var my_id = Meteor.userId();                                                                                  // 6
    return [Meteor.subscribe('notifications'), /*Meteor.subscribe('posts'),*/ /*Meteor.subscribe('comments'),*/ /*Meteor.subscribe('histoires'),*/Meteor.subscribe('requests'), /*Meteor.subscribe('friends'),*/Meteor.subscribe('chat_notif', my_id), /*Meteor.subscribe('userBloquer'),*/ /*Meteor.subscribe('contact_Chat'),*/Meteor.subscribe('userStatus'), /*Meteor.subscribe('userIP'),*/ /*Meteor.subscribe('visites'),*/ /*Meteor.subscribe('commentaires'),*/Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user'), /*Meteor.subscribe('user_bloquer_IP'),*/Meteor.subscribe('alertes'), Meteor.subscribe('delete_alertes'), /*Meteor.subscribe('conseilleres_acceuil'),*/Meteor.subscribe('lastlogin'), Meteor.subscribe('password')];
  }                                                                                                               // 30
});                                                                                                               // 1
PostsListController = RouteController.extend({                                                                    // 33
  template: 'postsList',                                                                                          // 34
  increment: 5,                                                                                                   // 35
  postsLimit: function () {                                                                                       // 36
    return parseInt(this.params.postsLimit) || this.increment;                                                    // 37
  },                                                                                                              // 38
  findOptions: function () {                                                                                      // 39
    return {                                                                                                      // 40
      sort: {                                                                                                     // 40
        post_date: -1                                                                                             // 40
      },                                                                                                          // 40
      limit: this.postsLimit()                                                                                    // 40
    };                                                                                                            // 40
  },                                                                                                              // 41
  subscriptions: function () {                                                                                    // 42
    this.postsSub = Meteor.subscribe('posts', this.findOptions());                                                // 43
  },                                                                                                              // 44
  posts: function () {                                                                                            // 45
    return Posts.find({}, this.findOptions());                                                                    // 46
  },                                                                                                              // 47
  data: function () {                                                                                             // 48
    var hasMore = this.posts().count() === this.postsLimit();                                                     // 49
    var nextPath = this.route.path({                                                                              // 50
      postsLimit: this.postsLimit() + this.increment                                                              // 50
    });                                                                                                           // 50
    return {                                                                                                      // 51
      posts: this.posts(),                                                                                        // 52
      ready: this.postsSub.ready,                                                                                 // 53
      nextPath: hasMore ? nextPath : null                                                                         // 54
    };                                                                                                            // 51
  },                                                                                                              // 56
  waitOn: function () {                                                                                           // 57
    return [Meteor.subscribe('comments'), Meteor.subscribe('contact_Chat_profil')];                               // 58
  }                                                                                                               // 64
});                                                                                                               // 33
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 67
  Router.plugin('reywood:iron-router-ga');                                                                        // 68
  Router.configure({                                                                                              // 69
    trackPageView: true                                                                                           // 70
  });                                                                                                             // 69
}                                                                                                                 // 72
                                                                                                                  //
Router.route('/', function () {                                                                                   // 75
  this.redirect('/index');                                                                                        // 76
});                                                                                                               // 77
Router.route('index/:postsLimit?', {                                                                              // 79
  name: 'postsList'                                                                                               // 80
});                                                                                                               // 79
Router.route('/posts/:_id', {                                                                                     // 85
  name: 'postPage',                                                                                               // 86
  template: 'postPage',                                                                                           // 87
  waitOn: function () {                                                                                           // 88
    return [Meteor.subscribe('Singleposts', this.params._id), Meteor.subscribe('comments', this.params._id)];     // 89
  },                                                                                                              // 93
  data: function () {                                                                                             // 94
    return Posts.findOne(this.params._id);                                                                        // 95
  }                                                                                                               // 96
});                                                                                                               // 85
Router.route('/posts_mobile/:_id', {                                                                              // 100
  name: 'postPage_mobile',                                                                                        // 101
  template: 'postPage_mobile',                                                                                    // 102
  waitOn: function () {                                                                                           // 103
    return [Meteor.subscribe('Singleposts', this.params._id), Meteor.subscribe('comments', this.params._id)];     // 104
  },                                                                                                              // 108
  data: function () {                                                                                             // 109
    return Posts.findOne(this.params._id);                                                                        // 110
  }                                                                                                               // 111
});                                                                                                               // 100
Router.route('/posts/:_id/edit', {                                                                                // 115
  name: 'postEdit',                                                                                               // 116
  data: function () {                                                                                             // 117
    return Posts.findOne(this.params._id);                                                                        // 118
  },                                                                                                              // 119
  waitOn: function () {                                                                                           // 120
    return [Meteor.subscribe('Singleposts', this.params._id)];                                                    // 121
  }                                                                                                               // 124
});                                                                                                               // 115
Router.route('/contact', {                                                                                        // 127
  name: 'contact',                                                                                                // 128
  template: 'contact'                                                                                             // 129
});                                                                                                               // 127
Router.route('/profil/:post_author?', {                                                                           // 133
  name: 'profil',                                                                                                 // 134
  template: 'profil',                                                                                             // 135
  data: function () {                                                                                             // 136
    return Meteor.users.findOne(this.params.post_author);                                                         // 137
  },                                                                                                              // 138
  waitOn: function () {                                                                                           // 139
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user')];
  }                                                                                                               // 150
});                                                                                                               // 133
Router.route('/profil/:_id', {                                                                                    // 155
  name: 'mon_profil',                                                                                             // 156
  template: 'profil',                                                                                             // 157
  waitOn: function () {                                                                                           // 158
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user')];
  }                                                                                                               // 169
});                                                                                                               // 155
Router.route('/messagerie/:post_author?', {                                                                       // 172
  name: 'messagerie',                                                                                             // 173
  template: 'messagerie',                                                                                         // 174
  waitOn: function () {                                                                                           // 175
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat')];
  },                                                                                                              // 181
  data: function () {                                                                                             // 182
    return Meteor.users.findOne(this.params.post_author);                                                         // 183
  }                                                                                                               // 184
});                                                                                                               // 172
Router.route('/messagerie_vierge/:post_author?', {                                                                // 187
  name: 'messagerie_vierge',                                                                                      // 188
  template: 'messagerie_vierge',                                                                                  // 189
  data: function () {                                                                                             // 190
    return Meteor.users.findOne(this.params.post_author);                                                         // 191
  },                                                                                                              // 192
  waitOn: function () {                                                                                           // 193
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat')];
  }                                                                                                               // 199
});                                                                                                               // 187
Router.route('/messagerie_mobile/:post_author?', {                                                                // 202
  name: 'messagerie_mobile',                                                                                      // 203
  template: 'messagerie_mobile',                                                                                  // 204
  data: function () {                                                                                             // 205
    return Meteor.users.findOne(this.params.post_author);                                                         // 206
  },                                                                                                              // 207
  waitOn: function () {                                                                                           // 208
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat')];
  }                                                                                                               // 214
});                                                                                                               // 202
Router.route('/mot_de_passe', {                                                                                   // 217
  name: 'mot_de_passe',                                                                                           // 218
  template: 'mot_de_passe'                                                                                        // 219
});                                                                                                               // 217
Router.route('/signaler_bug', {                                                                                   // 223
  name: 'signaler_bug',                                                                                           // 224
  template: 'signaler_bug'                                                                                        // 225
});                                                                                                               // 223
Router.route('/ameliore_site', {                                                                                  // 229
  name: 'ameliore_site',                                                                                          // 230
  template: 'ameliore_site'                                                                                       // 231
});                                                                                                               // 229
Router.route('/supprimer_compte', {                                                                               // 235
  name: 'supprimer_compte',                                                                                       // 236
  template: 'supprimer_compte'                                                                                    // 237
});                                                                                                               // 235
Router.route('/inscription', {                                                                                    // 241
  name: 'inscription',                                                                                            // 242
  template: 'inscription'                                                                                         // 243
});                                                                                                               // 241
Router.route('/devenir_conseillere', {                                                                            // 247
  name: 'devenir_conseillere',                                                                                    // 248
  template: 'devenir_conseillere'                                                                                 // 249
});                                                                                                               // 247
Router.route('/devenir_conseillere_mobile', {                                                                     // 253
  name: 'devenir_conseillere_mobile',                                                                             // 254
  template: 'devenir_conseillere_mobile'                                                                          // 255
});                                                                                                               // 253
Router.route('/confirmation_conseillere', {                                                                       // 259
  name: 'confirmation_conseillere',                                                                               // 260
  template: 'confirmation_conseillere'                                                                            // 261
});                                                                                                               // 259
Router.route('/confirmation_conseillere_mobile', {                                                                // 264
  name: 'confirmation_conseillere_mobile',                                                                        // 265
  template: 'confirmation_conseillere_mobile'                                                                     // 266
});                                                                                                               // 264
Router.route('/recherche_conseillere', {                                                                          // 269
  name: 'recherche_conseillere',                                                                                  // 270
  template: 'recherche_conseillere'                                                                               // 271
});                                                                                                               // 269
Router.route('/recherche_mobile', {                                                                               // 275
  name: 'recherche_mobile',                                                                                       // 276
  template: 'recherche_mobile'                                                                                    // 277
});                                                                                                               // 275
Router.route('/resultat_conseillere/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere',                                                                                   // 282
  template: 'resultat_conseillere',                                                                               // 283
  data: function () {                                                                                             // 284
    return Conseilleres.find();                                                                                   // 285
  },                                                                                                              // 286
  waitOn: function () {                                                                                           // 287
    return Meteor.subscribe('conseilleres');                                                                      // 288
  }                                                                                                               // 289
});                                                                                                               // 281
Router.route('/resultat_conseillere_mobile/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere_mobile',                                                                            // 294
  template: 'resultat_conseillere_mobile',                                                                        // 295
  data: function () {                                                                                             // 296
    return Conseilleres.find();                                                                                   // 297
  },                                                                                                              // 298
  waitOn: function () {                                                                                           // 299
    return Meteor.subscribe('conseilleres');                                                                      // 300
  }                                                                                                               // 301
});                                                                                                               // 293
Router.route('/classement-conseilleres', {                                                                        // 305
  name: 'classementComplet',                                                                                      // 306
  template: 'classementComplet',                                                                                  // 307
  waitOn: function () {                                                                                           // 308
    return Meteor.subscribe('conseilleres');                                                                      // 309
  }                                                                                                               // 310
});                                                                                                               // 305
Router.route('/classement-conseilleres-mobile', {                                                                 // 313
  name: 'classementComplet_mobile',                                                                               // 314
  template: 'classementComplet_mobile',                                                                           // 315
  waitOn: function () {                                                                                           // 316
    return Meteor.subscribe('conseilleres');                                                                      // 317
  }                                                                                                               // 318
});                                                                                                               // 313
Router.route('/conseiller/:post_author?', {                                                                       // 322
  name: 'presentation_conseiller',                                                                                // 323
  template: 'presentation_conseiller',                                                                            // 324
  data: function () {                                                                                             // 325
    return Meteor.users.findOne(this.params.post_author);                                                         // 326
  },                                                                                                              // 327
  waitOn: function () {                                                                                           // 328
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 339
});                                                                                                               // 322
Router.route('/presentation_conseiller_mobile/:post_author?', {                                                   // 342
  name: 'presentation_conseiller_mobile',                                                                         // 343
  template: 'presentation_conseiller_mobile',                                                                     // 344
  data: function () {                                                                                             // 345
    return Meteor.users.findOne(this.params.post_author);                                                         // 346
  }                                                                                                               // 346
});                                                                                                               // 342
Router.route('/histoire/:post_author?', {                                                                         // 351
  name: 'histoire',                                                                                               // 352
  template: 'histoire',                                                                                           // 353
  data: function () {                                                                                             // 354
    return Meteor.users.findOne(this.params.post_author);                                                         // 355
  },                                                                                                              // 356
  waitOn: function () {                                                                                           // 357
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 368
});                                                                                                               // 351
Router.route('/histoire_mobile/:post_author?', {                                                                  // 371
  name: 'histoire_mobile',                                                                                        // 372
  template: 'histoire_mobile',                                                                                    // 373
  data: function () {                                                                                             // 374
    return Meteor.users.findOne(this.params.post_author);                                                         // 375
  },                                                                                                              // 376
  waitOn: function () {                                                                                           // 377
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 388
});                                                                                                               // 371
Router.route('/amis/:post_author?', {                                                                             // 391
  name: 'amis',                                                                                                   // 392
  template: 'amis',                                                                                               // 393
  data: function () {                                                                                             // 394
    return Meteor.users.findOne(this.params.post_author);                                                         // 395
  },                                                                                                              // 396
  waitOn: function () {                                                                                           // 397
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 408
});                                                                                                               // 391
Router.route('/visites/:post_author?', {                                                                          // 411
  name: 'visites',                                                                                                // 412
  template: 'visites',                                                                                            // 413
  data: function () {                                                                                             // 414
    return Meteor.users.findOne(this.params.post_author);                                                         // 415
  },                                                                                                              // 416
  waitOn: function () {                                                                                           // 417
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 428
});                                                                                                               // 411
Router.route('/visites_mobile/:post_author?', {                                                                   // 431
  name: 'visites_mobile',                                                                                         // 432
  template: 'visites_mobile',                                                                                     // 433
  data: function () {                                                                                             // 434
    return Meteor.users.findOne(this.params.post_author);                                                         // 435
  },                                                                                                              // 436
  waitOn: function () {                                                                                           // 437
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 448
});                                                                                                               // 431
Router.route('/personne_aide/:post_author?', {                                                                    // 451
  name: 'personne_aide',                                                                                          // 452
  template: 'personne_aide',                                                                                      // 453
  data: function () {                                                                                             // 454
    return Meteor.users.findOne(this.params.post_author);                                                         // 455
  },                                                                                                              // 456
  waitOn: function () {                                                                                           // 457
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 468
});                                                                                                               // 451
Router.route('/personne_aide_mobile/:post_author?', {                                                             // 471
  name: 'personne_aide_mobile',                                                                                   // 472
  template: 'personne_aide_mobile',                                                                               // 473
  data: function () {                                                                                             // 474
    return Meteor.users.findOne(this.params.post_author);                                                         // 475
  },                                                                                                              // 476
  waitOn: function () {                                                                                           // 477
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 488
});                                                                                                               // 471
Router.route('/messages_poste/:post_author?', {                                                                   // 491
  name: 'messages_poste',                                                                                         // 492
  template: 'messages_poste',                                                                                     // 493
  data: function () {                                                                                             // 494
    return Meteor.users.findOne(this.params.post_author);                                                         // 495
  },                                                                                                              // 496
  waitOn: function () {                                                                                           // 497
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 508
});                                                                                                               // 491
Router.route('/messages_poste_mobile/:post_author?', {                                                            // 511
  name: 'messages_poste_mobile',                                                                                  // 512
  template: 'messages_poste_mobile',                                                                              // 513
  data: function () {                                                                                             // 514
    return Meteor.users.findOne(this.params.post_author);                                                         // 515
  },                                                                                                              // 516
  waitOn: function () {                                                                                           // 517
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 528
});                                                                                                               // 511
Router.route('/commentaires/:post_author?', {                                                                     // 531
  name: 'commentaires',                                                                                           // 532
  template: 'commentaires',                                                                                       // 533
  data: function () {                                                                                             // 534
    return Meteor.users.findOne(this.params.post_author);                                                         // 535
  },                                                                                                              // 536
  waitOn: function () {                                                                                           // 537
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 548
});                                                                                                               // 531
Router.route('/commentaires_mobile/:post_author?', {                                                              // 551
  name: 'commentaires_mobile',                                                                                    // 552
  template: 'commentaires_mobile',                                                                                // 553
  data: function () {                                                                                             // 554
    return Meteor.users.findOne(this.params.post_author);                                                         // 555
  },                                                                                                              // 556
  waitOn: function () {                                                                                           // 557
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 568
});                                                                                                               // 551
Router.route('/rediger_commentaires_mobile/:post_author?', {                                                      // 571
  name: 'rediger_commentaires_mobile',                                                                            // 572
  template: 'rediger_commentaires_mobile',                                                                        // 573
  data: function () {                                                                                             // 574
    return Meteor.users.findOne(this.params.post_author);                                                         // 575
  },                                                                                                              // 576
  waitOn: function () {                                                                                           // 577
    return Meteor.subscribe('commentaires');                                                                      // 578
  }                                                                                                               // 579
});                                                                                                               // 571
Router.route('/ils_ont_aide/:post_author?', {                                                                     // 582
  name: 'ils_ont_aide',                                                                                           // 583
  template: 'ils_ont_aide',                                                                                       // 584
  data: function () {                                                                                             // 585
    return Meteor.users.findOne(this.params.post_author);                                                         // 586
  },                                                                                                              // 587
  waitOn: function () {                                                                                           // 588
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 599
});                                                                                                               // 582
Router.route('/ils_ont_aide_mobile/:post_author?', {                                                              // 602
  name: 'ils_ont_aide_mobile',                                                                                    // 603
  template: 'ils_ont_aide_mobile',                                                                                // 604
  data: function () {                                                                                             // 605
    return Meteor.users.findOne(this.params.post_author);                                                         // 606
  },                                                                                                              // 607
  waitOn: function () {                                                                                           // 608
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 619
});                                                                                                               // 602
Router.route('/alerte/:post_author?', {                                                                           // 622
  name: 'alerte',                                                                                                 // 623
  template: 'alerte',                                                                                             // 624
  data: function () {                                                                                             // 625
    return Meteor.users.findOne(this.params.post_author);                                                         // 626
  },                                                                                                              // 627
  waitOn: function () {                                                                                           // 628
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 639
});                                                                                                               // 622
Router.route('/avertissement/:post_author?', {                                                                    // 642
  name: 'avertissement',                                                                                          // 643
  template: 'avertissement',                                                                                      // 644
  data: function () {                                                                                             // 645
    return Meteor.users.findOne(this.params.post_author);                                                         // 646
  },                                                                                                              // 647
  waitOn: function () {                                                                                           // 648
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 659
});                                                                                                               // 642
Router.route('/avertissement_mobile/:post_author?', {                                                             // 662
  name: 'avertissement_mobile',                                                                                   // 663
  template: 'avertissement_mobile',                                                                               // 664
  data: function () {                                                                                             // 665
    return Meteor.users.findOne(this.params.post_author);                                                         // 666
  },                                                                                                              // 667
  waitOn: function () {                                                                                           // 668
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 679
});                                                                                                               // 662
Router.route('/add_commentaire_mobile/:post_author?', {                                                           // 682
  name: 'add_commentaire_mobile',                                                                                 // 683
  template: 'add_commentaire_mobile',                                                                             // 684
  data: function () {                                                                                             // 685
    return Meteor.users.findOne(this.params.post_author);                                                         // 686
  }                                                                                                               // 686
});                                                                                                               // 682
Router.route('/valider_commentaire_mobile/:post_author?', {                                                       // 689
  name: 'valider_commentaire_mobile',                                                                             // 690
  template: 'valider_commentaire_mobile',                                                                         // 691
  data: function () {                                                                                             // 692
    return Meteor.users.findOne(this.params.post_author);                                                         // 693
  }                                                                                                               // 693
});                                                                                                               // 689
Router.route('/presentation/:post_author?', {                                                                     // 696
  name: 'presentation',                                                                                           // 697
  template: 'presentation',                                                                                       // 698
  data: function () {                                                                                             // 699
    return Meteor.users.findOne(this.params.post_author);                                                         // 700
  },                                                                                                              // 701
  waitOn: function () {                                                                                           // 702
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 713
});                                                                                                               // 696
Router.route('/alertes_mobile/:post_author?', {                                                                   // 716
  name: 'alertes_mobile',                                                                                         // 717
  template: 'alertes_mobile',                                                                                     // 718
  data: function () {                                                                                             // 719
    return Meteor.users.findOne(this.params.post_author);                                                         // 720
  }                                                                                                               // 720
});                                                                                                               // 716
Router.route('/creerAlerte/:post_author?', {                                                                      // 723
  name: 'creerAlerte',                                                                                            // 724
  template: 'creerAlerte',                                                                                        // 725
  data: function () {                                                                                             // 726
    return Meteor.users.findOne(this.params.post_author);                                                         // 727
  }                                                                                                               // 727
});                                                                                                               // 723
Router.route('/valider_Alerte/:post_author?', {                                                                   // 730
  name: 'valider_Alerte',                                                                                         // 731
  template: 'valider_Alerte',                                                                                     // 732
  data: function () {                                                                                             // 733
    return Meteor.users.findOne(this.params.post_author);                                                         // 734
  }                                                                                                               // 734
});                                                                                                               // 730
Router.route('/presentation_mobile/:post_author?', {                                                              // 737
  name: 'presentation_mobile',                                                                                    // 738
  template: 'presentation_mobile',                                                                                // 739
  data: function () {                                                                                             // 740
    return Meteor.users.findOne(this.params.post_author);                                                         // 741
  }                                                                                                               // 741
});                                                                                                               // 737
Router.route('/notifications_mobile', {                                                                           // 744
  name: 'notifications_mobile',                                                                                   // 745
  template: 'notifications_mobile1'                                                                               // 746
});                                                                                                               // 744
Router.route('/profil_mobile/:post_author?', {                                                                    // 750
  name: 'profil_mobile',                                                                                          // 751
  template: 'profil_mobile',                                                                                      // 752
  data: function () {                                                                                             // 753
    return Meteor.users.findOne(this.params.post_author);                                                         // 754
  },                                                                                                              // 755
  waitOn: function () {                                                                                           // 756
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 767
});                                                                                                               // 750
Router.route('/amis_mobile/:post_author?', {                                                                      // 770
  name: 'amis_mobile',                                                                                            // 771
  template: 'amis_mobile',                                                                                        // 772
  data: function () {                                                                                             // 773
    return Meteor.users.findOne(this.params.post_author);                                                         // 774
  },                                                                                                              // 775
  waitOn: function () {                                                                                           // 776
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler')];
  }                                                                                                               // 787
});                                                                                                               // 770
Router.route('/connexion_mobile', {                                                                               // 790
  name: 'connexion_mobile',                                                                                       // 791
  template: 'connexion_mobile'                                                                                    // 792
});                                                                                                               // 790
Router.route('/supprimer_mon_compte', {                                                                           // 795
  name: 'supprimer_mon_compte',                                                                                   // 796
  template: 'supprimer_mon_compte'                                                                                // 797
});                                                                                                               // 795
Router.route('/dashboard', {                                                                                      // 800
  name: 'dashboard',                                                                                              // 801
  template: 'dashboard'                                                                                           // 802
});                                                                                                               // 800
Router.route('/dons', {                                                                                           // 805
  name: 'dons',                                                                                                   // 806
  template: 'dons'                                                                                                // 807
});                                                                                                               // 805
Router.route('/cgu', {                                                                                            // 810
  name: 'cgu',                                                                                                    // 811
  template: 'cgu'                                                                                                 // 812
}); /*Router.route('/le_secret_de_cendrillon', function() {                                                       // 810
        var filePath = process.env.PWD + "/server/le_secret_de_cendrillon.pdf";                                   //
        var fs = Meteor.npmRequire('fs');                                                                         //
        var data = fs.readFileSync(filePath);                                                                     //
        this.response.write(data);                                                                                //
        this.response.end();                                                                                      //
    }, {                                                                                                          //
        where: 'server'                                                                                           //
    });*/                                                                                                         //
Router.route('/le_secret_de_cendrillon', {                                                                        // 826
  name: 'le_secret_de_cendrillon',                                                                                // 827
  template: 'le_secret_de_cendrillon'                                                                             // 828
});                                                                                                               // 826
Router.onBeforeAction('dataNotFound', {                                                                           // 831
  only: 'postPage'                                                                                                // 831
});                                                                                                               // 831
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixture.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/fixture.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
  Meteor: function (v) {                                                                                          // 1
    Meteor = v;                                                                                                   // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
module.watch(require("meteor/houston:admin"));                                                                    // 1
Houston.add_collection(Meteor.users);                                                                             // 6
Houston.add_collection(Houston._admins); /*var now = new Date().getTime();                                        // 7
                                           // crée deux utilisateurs                                              //
                                          var tomId = Meteor.users.insert({                                       //
                                            profile: { name: 'Tom Coleman' }                                      //
                                          });                                                                     //
                                          var tom = Meteor.users.findOne(tomId);                                  //
                                          var sachaId = Meteor.users.insert({                                     //
                                            profile: { name: 'Sacha Greif' }                                      //
                                          });                                                                     //
                                          var sacha = Meteor.users.findOne(sachaId);                              //
                                           var telescopeId = Posts.insert({                                       //
                                            post_title: 'Introducing Telescope',                                  //
                                            post_author: sacha._id,                                               //
                                            author_name: sacha.profile.name,                                      //
                                            //url: 'http://sachagreif.com/introducing-telescope/',                //
                                            post_date: new Date(now - 7 * 3600 * 1000)                            //
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: tom._id,                                                      //
                                            author: tom.profile.name,                                             //
                                            submitted: new Date(now - 5 * 3600 * 1000),                           //
                                            body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: sacha._id,                                                    //
                                            author: sacha.profile.name,                                           //
                                            submitted: new Date(now - 3 * 3600 * 1000),                           //
                                            body: 'Bien sûr Tom !'                                                //
                                          });                                                                     //
                                           Posts.insert({                                                         //
                                            post_title: 'Meteor',                                                 //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://meteor.com',                                           //
                                            post_date: new Date(now - 10 * 3600 * 1000)                           //
                                          });                                                                     //
                                            Posts.insert({                                                        //
                                            post_title: 'The Meteor Book',                                        //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://themeteorbook.com',                                    //
                                            post_date: new Date(now - 12 * 3600 * 1000)                           //
                                          });*/ /*                                                                //
                                                    var now = new Date().getTime();                               //
                                                                                                                  //
                                                  // Créer deux utilisateurs                                      //
                                                  var tomId = Meteor.users.insert({                               //
                                                    profile: { name: 'Tom Coleman' }                              //
                                                  });                                                             //
                                                  var tom = Meteor.users.findOne(tomId);                          //
                                                  var sachaId = Meteor.users.insert({                             //
                                                    profile: { name: 'Sacha Greif' }                              //
                                                  });                                                             //
                                                  var sacha = Meteor.users.findOne(sachaId);                      //
                                                                                                                  //
                                                  var telescopeId = Posts.insert({                                //
                                                    title: 'Introducing Telescope',                               //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    url: 'http://sachagreif.com/introducing-telescope/',          //
                                                    submitted: new Date(now - 7 * 3600 * 1000),                   //
                                                    commentsCount: 2,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    submitted: new Date(now - 5 * 3600 * 1000),                   //
                                                    body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    submitted: new Date(now - 3 * 3600 * 1000),                   //
                                                    body: 'Bien sûr Tom !'                                        //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'Meteor',                                              //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://meteor.com',                                     //
                                                    submitted: new Date(now - 10 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'The Meteor Book',                                     //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://themeteorbook.com',                              //
                                                    submitted: new Date(now - 12 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  for (var i = 0; i < 10; i++) {                                  //
                                                    Posts.insert({                                                //
                                                      title: 'Test post #' + i,                                   //
                                                      author: sacha.profile.name,                                 //
                                                      userId: sacha._id,                                          //
                                                      url: 'http://google.com/?q=test-' + i,                      //
                                                      submitted: new Date(now - i * 3600 * 1000 + 1),             //
                                                      commentsCount: 0,                                           //
                                                      upvoters: [],                                               //
                                                      votes: 0                                                    //
                                                    });                                                           //
                                                  }                                                               //
                                                */                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/items.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("items", function () {                                                                             // 1
  if (Roles.userIsInRole(this.userId, 'paid')) {                                                                  // 2
    return Items.find();                                                                                          // 3
  }                                                                                                               // 4
});                                                                                                               // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publication.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publication.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish('posts', function (options) {                                                                      // 1
  return Posts.find({}, options);                                                                                 // 2
});                                                                                                               // 3
Meteor.publish('Singleposts', function (id) {                                                                     // 6
  return Posts.find(id);                                                                                          // 7
});                                                                                                               // 8
Meteor.publish('users', function () {                                                                             // 11
  return Meteors.users.find();                                                                                    // 12
});                                                                                                               // 13
Meteor.publish('comments', function () {                                                                          // 15
  return Comments.find();                                                                                         // 16
});                                                                                                               // 17
Meteor.publish('notifications', function () {                                                                     // 20
  return Notifications.find({                                                                                     // 21
    userId: this.userId,                                                                                          // 21
    read: false                                                                                                   // 21
  });                                                                                                             // 21
});                                                                                                               // 22
Meteor.publish('histoires', function () {                                                                         // 24
  return Histoires.find();                                                                                        // 25
});                                                                                                               // 26
Meteor.publish('requests', function () {                                                                          // 28
  return Requests.find();                                                                                         // 29
});                                                                                                               // 30
Meteor.publish('friends', function () {                                                                           // 32
  return Friends.find();                                                                                          // 33
});                                                                                                               // 34
Meteor.publish('chat', function (id) {                                                                            // 36
  var my_id = Meteor.userId();                                                                                    // 37
  return Chat.find({                                                                                              // 38
    $or: [{                                                                                                       // 38
      from_id: id,                                                                                                // 39
      to_id: my_id                                                                                                // 39
    }, {                                                                                                          // 39
      to_id: id,                                                                                                  // 40
      from_id: my_id                                                                                              // 40
    }]                                                                                                            // 40
  });                                                                                                             // 38
});                                                                                                               // 42
Meteor.publish('chat_notif', function (id) {                                                                      // 44
  return Chat.find({                                                                                              // 45
    $or: [{                                                                                                       // 45
      from_id: id                                                                                                 // 46
    }, {                                                                                                          // 46
      to_id: id                                                                                                   // 47
    }]                                                                                                            // 47
  });                                                                                                             // 45
});                                                                                                               // 49
Meteor.publish('userBloquer', function () {                                                                       // 52
  return UserBloquer.find();                                                                                      // 53
});                                                                                                               // 54
Meteor.publish('contact_Chat', function () {                                                                      // 56
  var id = Meteor.userId();                                                                                       // 57
  return ContactChat.find({                                                                                       // 58
    $or: [{                                                                                                       // 58
      from_id: id                                                                                                 // 59
    }, {                                                                                                          // 59
      to_id: id                                                                                                   // 60
    }]                                                                                                            // 60
  });                                                                                                             // 58
});                                                                                                               // 62
Meteor.publish('contact_Chat_profil', function () {                                                               // 64
  return ContactChat.find();                                                                                      // 65
});                                                                                                               // 66
Meteor.publish("userStatus", function () {                                                                        // 68
  return Meteor.users.find({                                                                                      // 69
    "status.online": true                                                                                         // 69
  });                                                                                                             // 69
});                                                                                                               // 70
Meteor.publish("password", function () {                                                                          // 72
  return Meteor.users.find({                                                                                      // 73
    "services.password.bcrypt": true                                                                              // 73
  });                                                                                                             // 73
});                                                                                                               // 74
Meteor.publish("visites", function () {                                                                           // 77
  return Visites.find();                                                                                          // 78
});                                                                                                               // 79
Meteor.publish('commentaires', function () {                                                                      // 81
  return Commentaires.find();                                                                                     // 82
});                                                                                                               // 83
Meteor.publish('messages_signaler', function () {                                                                 // 85
  return Signaler.find();                                                                                         // 86
});                                                                                                               // 87
Meteor.publish('avertissement_user', function () {                                                                // 89
  return Avertissement.find();                                                                                    // 90
});                                                                                                               // 91
Meteor.publish("userIP", function () {                                                                            // 93
  return Meteor.users.find({}, {                                                                                  // 94
    "status.lastLogin.ipAddr": true                                                                               // 94
  });                                                                                                             // 94
});                                                                                                               // 95
Meteor.publish("lastlogin", function () {                                                                         // 97
  return Meteor.users.find({}, {                                                                                  // 98
    "status.lastLogin.date": true                                                                                 // 98
  });                                                                                                             // 98
});                                                                                                               // 99
Meteor.publish('user_bloquer_IP', function () {                                                                   // 101
  return UserBloquer_IP.find();                                                                                   // 102
});                                                                                                               // 103
Meteor.publish('alertes', function () {                                                                           // 105
  return Alertes.find();                                                                                          // 106
});                                                                                                               // 107
Meteor.publish('delete_alertes', function () {                                                                    // 109
  return DeleteAlertes.find();                                                                                    // 110
});                                                                                                               // 111
Meteor.publish('conseilleres_acceuil', function () {                                                              // 113
  return Conseilleres.find({}, {                                                                                  // 114
    limit: 10                                                                                                     // 114
  });                                                                                                             // 114
});                                                                                                               // 115
Meteor.publish('conseilleres', function () {                                                                      // 117
  return Conseilleres.find();                                                                                     // 118
});                                                                                                               // 119
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
Meteor.startup(function () {}); /*Accounts.onCreateUser(function( user) {                                         // 4
                                    /*console.log(user);                                                          //
                                    return user;                                                                  //
                                });*/                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// mup.js                                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exports = {                                                                                                // 1
  servers: {                                                                                                      // 2
    one: {                                                                                                        // 3
      // TODO: set host address, username, and authentication method                                              // 4
      host: '151.80.146.217',                                                                                     // 5
      username: 'root',                                                                                           // 6
      // pem: './path/to/pem'                                                                                     // 7
      password: 'mT9nQ5Pm' // or neither for authenticate from ssh-agent                                          // 8
                                                                                                                  //
    }                                                                                                             // 3
  },                                                                                                              // 2
  app: {                                                                                                          // 13
    // TODO: change app name and path                                                                             // 14
    name: 'kurbys',                                                                                               // 15
    path: '../kurbys',                                                                                            // 16
    servers: {                                                                                                    // 18
      one: {}                                                                                                     // 19
    },                                                                                                            // 18
    buildOptions: {                                                                                               // 22
      serverOnly: true                                                                                            // 23
    },                                                                                                            // 22
    env: {                                                                                                        // 26
      // TODO: Change to your app's url                                                                           // 27
      // If you are using ssl, it needs to start with https://                                                    // 28
      ROOT_URL: 'https://www.kurbys.com',                                                                         // 29
      MONGO_URL: 'mongodb://151.80.146.217:27017/meteor'                                                          // 30
    },                                                                                                            // 26
    ssl: {                                                                                                        // 33
      // (optional)                                                                                               // 33
      // Enables let's encrypt (optional)                                                                         // 34
      autogenerate: {                                                                                             // 35
        email: 'jbroussat@orange.fr',                                                                             // 36
        // comma separated list of domains                                                                        // 37
        domains: 'kurbys.com,www.kurbys.com'                                                                      // 38
      }                                                                                                           // 35
    },                                                                                                            // 33
    docker: {                                                                                                     // 42
      // change to 'kadirahq/meteord' if your app is using Meteor 1.3 or older                                    // 43
      image: 'abernix/meteord:base'                                                                               // 44
    },                                                                                                            // 42
    // Show progress bar while uploading bundle to server                                                         // 47
    // You might need to disable it on CI servers                                                                 // 48
    enableUploadProgressBar: true                                                                                 // 49
  },                                                                                                              // 13
  mongo: {                                                                                                        // 52
    version: '3.4.9',                                                                                             // 53
    servers: {                                                                                                    // 54
      one: {}                                                                                                     // 55
    }                                                                                                             // 54
  }                                                                                                               // 52
};                                                                                                                // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".coffee"
  ]
});
require("./lib/Collections/Chat.js");
require("./lib/Collections/UserBloquer.js");
require("./lib/Collections/alerte.js");
require("./lib/Collections/avertissement.js");
require("./lib/Collections/comment.js");
require("./lib/Collections/commentaires.js");
require("./lib/Collections/conseilleres.js");
require("./lib/Collections/contact_chat.js");
require("./lib/Collections/delete_alerte.js");
require("./lib/Collections/friends.js");
require("./lib/Collections/histoire.js");
require("./lib/Collections/messages_signaler.js");
require("./lib/Collections/notifications.js");
require("./lib/Collections/posts.js");
require("./lib/Collections/request.js");
require("./lib/Collections/user.js");
require("./lib/Collections/userBloquer_IP.js");
require("./lib/Collections/visites.js");
require("./lib/permission.js");
require("./lib/router.js");
require("./server/fixture.js");
require("./server/items.js");
require("./server/publication.js");
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
