var require = meteorInstall({"lib":{"Collections":{"Chat.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/Chat.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Chat = new Mongo.Collection('chat');                                                                              // 1
Chat.allow({                                                                                                      // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    message: function (postAttributes) {                                                                          // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date(),                                                                                // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Chat.insert(post);                                                                           // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    },                                                                                                            // 20
    AddFavorisChat: function (postAttributes) {                                                                   // 22
        var user = Meteor.user();                                                                                 // 23
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 24
            author_name_add_favoris: user.username,                                                               // 25
            post_date: new Date()                                                                                 // 26
        });                                                                                                       // 24
                                                                                                                  //
        var postId = Favoris.insert(post);                                                                        // 28
        return {                                                                                                  // 29
            _id: postId                                                                                           // 30
        };                                                                                                        // 29
    },                                                                                                            // 32
    bloquer_user: function (postAttributes) {                                                                     // 34
        var post = _.extend(postAttributes, {                                                                     // 35
            date: new Date()                                                                                      // 36
        });                                                                                                       // 35
                                                                                                                  //
        var postId = UserBloquer.insert(post);                                                                    // 38
        return {                                                                                                  // 39
            _id: postId                                                                                           // 40
        };                                                                                                        // 39
    }                                                                                                             // 42
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserBloquer.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/UserBloquer.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer = new Mongo.Collection('userBloquer');                                                                // 1
UserBloquer.allow({                                                                                               // 3
  update: function (userId) {                                                                                     // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId) {                                                                                     // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/alerte.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Alertes = new Mongo.Collection('alertes');                                                                        // 1
Alertes.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    alerteInsert: function (postAttributes) {                                                                     // 11
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            author_id: user._id,                                                                                  // 14
            author_name: user.username,                                                                           // 15
            gender: user.profile.gender,                                                                          // 16
            post_date: new Date()                                                                                 // 17
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 19
        return {                                                                                                  // 20
            _id: postId                                                                                           // 21
        };                                                                                                        // 20
    },                                                                                                            // 23
    alerteInsert1: function (postAttributes) {                                                                    // 25
        var user = Meteor.user();                                                                                 // 26
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 27
            author_id: user._id,                                                                                  // 28
            author_name: user.username,                                                                           // 29
            gender: user.profile.gender,                                                                          // 30
            post_date: new Date()                                                                                 // 31
        });                                                                                                       // 27
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 33
        return {                                                                                                  // 34
            _id: postId                                                                                           // 35
        };                                                                                                        // 34
    }                                                                                                             // 37
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"avertissement.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/avertissement.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Avertissement = new Mongo.Collection('avertissement_user');                                                       // 1
Avertissement.allow({                                                                                             // 3
  insert: function (userId, post) {                                                                               // 4
    return true;                                                                                                  // 4
  },                                                                                                              // 4
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comment.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/comment.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Comments = new Mongo.Collection('comments');                                                                      // 1
Meteor.methods({                                                                                                  // 4
  commentInsert: function (commentAttributes) {                                                                   // 5
    /*check(this.userId, String);                                                                                 // 6
    check(commentAttributes, {                                                                                    //
      postId: String,                                                                                             //
      body: String                                                                                                //
    });*/var user = Meteor.user();                                                                                //
    var post = Posts.findOne(commentAttributes.postId);                                                           // 12
    if (!post) throw new Meteor.Error('invalid-comment', 'Vous devez commenter sur un post');                     // 13
    comment = _.extend(commentAttributes, {                                                                       // 15
      userId: user._id,                                                                                           // 16
      gender: user.profile.gender,                                                                                // 17
      author: user.username,                                                                                      // 18
      submitted: new Date(),                                                                                      // 19
      upvoters: [],                                                                                               // 20
      votes: 0,                                                                                                   // 21
      nbr_votant: 0                                                                                               // 22
    }); // crée le commentaire et enregistre l'id                                                                 // 15
                                                                                                                  //
    comment._id = Comments.insert(comment); // crée maintenant une notification, informant l'utilisateur qu'il y a eu un commentaire
                                                                                                                  //
    createCommentNotification(comment);                                                                           // 27
    return comment._id;                                                                                           // 28
  },                                                                                                              // 29
  upvote: function (commentId) {                                                                                  // 31
    check(this.userId, String);                                                                                   // 32
    check(commentId, String);                                                                                     // 33
    var comment = Comments.findOne(commentId);                                                                    // 34
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 35
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 39
      $addToSet: {                                                                                                // 40
        upvoters: this.userId                                                                                     // 40
      },                                                                                                          // 40
      $inc: {                                                                                                     // 41
        votes: 1                                                                                                  // 41
      }                                                                                                           // 41
    });                                                                                                           // 39
    Comments.update(comment._id, {                                                                                // 43
      $inc: {                                                                                                     // 44
        nbr_votant: 1                                                                                             // 44
      }                                                                                                           // 44
    });                                                                                                           // 43
  },                                                                                                              // 46
  downvote: function (commentId) {                                                                                // 48
    check(this.userId, String);                                                                                   // 49
    check(commentId, String);                                                                                     // 50
    var comment = Comments.findOne(commentId);                                                                    // 51
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 52
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 56
      $addToSet: {                                                                                                // 57
        upvoters: this.userId                                                                                     // 57
      },                                                                                                          // 57
      $inc: {                                                                                                     // 58
        votes: -1                                                                                                 // 58
      }                                                                                                           // 58
    });                                                                                                           // 56
    Comments.update(comment._id, {                                                                                // 60
      $inc: {                                                                                                     // 61
        nbr_votant: 1                                                                                             // 61
      }                                                                                                           // 61
    });                                                                                                           // 60
  }                                                                                                               // 63
});                                                                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentaires.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/commentaires.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Commentaires = new Mongo.Collection('commentaires');                                                              // 1
Commentaires.allow({                                                                                              // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    AddComment: function (postAttributes) {                                                                       // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            date: new Date(),                                                                                     // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Commentaires.insert(post);                                                                   // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"conseilleres.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/conseilleres.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Conseilleres = new Mongo.Collection('conseilleres');                                                              // 1
Conseilleres.allow({                                                                                              // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  AddConseillere: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      user_id: user._id,                                                                                          // 13
      username: user.username,                                                                                    // 14
      gender: user.profile.gender,                                                                                // 15
      date: new Date(),                                                                                           // 16
      lastLogin: new Date()                                                                                       // 17
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Conseilleres.insert(post);                                                                       // 19
    return {                                                                                                      // 20
      _id: postId                                                                                                 // 21
    };                                                                                                            // 20
  }                                                                                                               // 23
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"contact_chat.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/contact_chat.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _objectDestructuringEmpty2 = require("babel-runtime/helpers/objectDestructuringEmpty");                       //
                                                                                                                  //
var _objectDestructuringEmpty3 = _interopRequireDefault(_objectDestructuringEmpty2);                              //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
ContactChat = new Mongo.Collection('contact_Chat');                                                               // 1
ContactChat.allow({                                                                                               // 3
  update: function () {                                                                                           // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (_ref) {                                                                                       // 6
    (0, _objectDestructuringEmpty3.default)(_ref);                                                                // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  contact_chat: function (postAttributes) {                                                                       // 10
    var post = _.extend(postAttributes, {                                                                         // 11
      date: new Date(),                                                                                           // 12
      last_message: ' ',                                                                                          // 13
      read: false                                                                                                 // 14
    });                                                                                                           // 11
                                                                                                                  //
    var postId = ContactChat.insert(post);                                                                        // 16
    return {                                                                                                      // 17
      _id: postId                                                                                                 // 18
    };                                                                                                            // 17
  }                                                                                                               // 20
});                                                                                                               // 9
Meteor.methods({                                                                                                  // 25
  update_active: function (postAttributes) {                                                                      // 26
    var userId = Meteor.userId();                                                                                 // 27
                                                                                                                  //
    if (postAttributes.id_from_active) {                                                                          // 28
      ContactChat.update({                                                                                        // 29
        from_id: userId                                                                                           // 29
      }, {                                                                                                        // 29
        $set: {                                                                                                   // 29
          "id_from_active": false                                                                                 // 29
        }                                                                                                         // 29
      }, {                                                                                                        // 29
        multi: true                                                                                               // 29
      });                                                                                                         // 29
      ContactChat.update({                                                                                        // 30
        _id: postAttributes._id                                                                                   // 30
      }, {                                                                                                        // 30
        $set: {                                                                                                   // 30
          "id_from_active": true                                                                                  // 30
        }                                                                                                         // 30
      });                                                                                                         // 30
    }                                                                                                             // 30
                                                                                                                  //
    if (postAttributes.id_to_active) {                                                                            // 32
      ContactChat.update({                                                                                        // 33
        to_id: userId                                                                                             // 33
      }, {                                                                                                        // 33
        $set: {                                                                                                   // 33
          "id_to_active": false                                                                                   // 33
        }                                                                                                         // 33
      }, {                                                                                                        // 33
        multi: true                                                                                               // 33
      });                                                                                                         // 33
      ContactChat.update({                                                                                        // 34
        _id: postAttributes._id                                                                                   // 34
      }, {                                                                                                        // 34
        $set: {                                                                                                   // 34
          "id_to_active": true                                                                                    // 34
        }                                                                                                         // 34
      });                                                                                                         // 34
    } //ContactChat.update({from_id : userId}, {$set:{ "active" : false }} );                                     // 34
    //ContactChat.update({to_id : userId}, {$set:{ "active" : false }} );                                         // 36
                                                                                                                  //
                                                                                                                  //
    ContactChat.update({                                                                                          // 37
      _id: postAttributes._id                                                                                     // 37
    }, {                                                                                                          // 37
      $set: {                                                                                                     // 37
        "active": true                                                                                            // 37
      }                                                                                                           // 37
    });                                                                                                           // 37
  }                                                                                                               // 38
});                                                                                                               // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"delete_alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/delete_alerte.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
DeleteAlertes = new Mongo.Collection('delete_alertes');                                                           // 1
DeleteAlertes.allow({                                                                                             // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    delete_alerte: function (postAttributes) {                                                                    // 10
        var post = _.extend(postAttributes, {});                                                                  // 11
                                                                                                                  //
        var postId = DeleteAlertes.insert(post);                                                                  // 14
        return {                                                                                                  // 15
            _id: postId                                                                                           // 16
        };                                                                                                        // 15
    }                                                                                                             // 18
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"favoris.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/favoris.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Favoris = new Mongo.Collection('favoris');                                                                        // 1
Favoris.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return ownsDocument(userId, post);                                                                        // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return ownsDocument(userId, post);                                                                        // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.users.allow({                                                                                              // 9
    update: function (userId, post) {                                                                             // 10
        return true;                                                                                              // 10
    }                                                                                                             // 10
});                                                                                                               // 9
Meteor.methods({                                                                                                  // 14
    AddFavoris: function (postAttributes) {                                                                       // 15
        var user = Meteor.user();                                                                                 // 16
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 17
            author_name_add_favoris: user.username,                                                               // 18
            post_date: new Date()                                                                                 // 19
        });                                                                                                       // 17
                                                                                                                  //
        var postId = Favoris.insert(post);                                                                        // 21
        return {                                                                                                  // 22
            _id: postId                                                                                           // 23
        };                                                                                                        // 22
    }                                                                                                             // 25
});                                                                                                               // 14
                                                                                                                  //
validatePost = function (post) {                                                                                  // 29
    var errors = {};                                                                                              // 30
    if (!post.post_title) errors.title = "Please fill in a headline";                                             // 31
    if (!post.content) errors.url = "Please fill in a URL";                                                       // 33
    return errors;                                                                                                // 35
};                                                                                                                // 36
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"friends.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/friends.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Friends = new Mongo.Collection('friends');                                                                        // 1
Friends.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    ami_accepte: function (postAttributes) {                                                                      // 10
        /*check(Meteor.userId(), String);                                                                         // 11
        check(postAttributes, {                                                                                   //
            post_title: String,                                                                                   //
            post_content: String,                                                                                 //
            categorie: String                                                                                     //
        });*/var user = Meteor.user();                                                                            //
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 18
            date: new Date()                                                                                      // 19
        });                                                                                                       // 18
                                                                                                                  //
        var postId = Friends.insert(post);                                                                        // 22
        return {                                                                                                  // 23
            _id: postId                                                                                           // 24
        };                                                                                                        // 23
    }                                                                                                             // 26
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"histoire.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/histoire.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Histoires = new Mongo.Collection('histoires');                                                                    // 1
Histoires.allow({                                                                                                 // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  histoireInsert: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      post_author: user._id,                                                                                      // 13
      author_name: user.username,                                                                                 // 14
      gender: user.profile.gender,                                                                                // 15
      post_date: new Date()                                                                                       // 16
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Histoires.insert(post);                                                                          // 18
    return {                                                                                                      // 19
      _id: postId                                                                                                 // 20
    };                                                                                                            // 19
  }                                                                                                               // 22
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages_signaler.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/messages_signaler.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Signaler = new Mongo.Collection('messages_signaler');                                                             // 1
Signaler.allow({                                                                                                  // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    signaler_message: function (postAttributes) {                                                                 // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = Signaler.insert(post);                                                                       // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/notifications.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Notifications = new Mongo.Collection('notifications');                                                            // 1
Notifications.allow({                                                                                             // 3
  update: function (userId, doc, fieldNames) {                                                                    // 4
    return ownsDocument(userId, doc) && fieldNames.length === 1 && fieldNames[0] === 'read';                      // 5
  }                                                                                                               // 7
});                                                                                                               // 3
                                                                                                                  //
createCommentNotification = function (comment) {                                                                  // 10
  var post = Posts.findOne(comment.postId);                                                                       // 11
                                                                                                                  //
  if (comment.userId !== post.post_author) {                                                                      // 12
    Notifications.insert({                                                                                        // 13
      userId: post.post_author,                                                                                   // 14
      postId: post._id,                                                                                           // 15
      commentId: comment._id,                                                                                     // 16
      commenterName: comment.author,                                                                              // 17
      read: false                                                                                                 // 18
    });                                                                                                           // 13
  }                                                                                                               // 20
};                                                                                                                // 21
                                                                                                                  //
createFriendsNotification = function (post) {                                                                     // 23
  Notifications.insert({                                                                                          // 24
    from_id: post.from_id,                                                                                        // 25
    to_id: post.to_id,                                                                                            // 26
    name_from_id: post.name_from_id,                                                                              // 27
    name_to_id: post.name_to_id,                                                                                  // 28
    date: post.date,                                                                                              // 29
    read: false                                                                                                   // 30
  });                                                                                                             // 24
};                                                                                                                // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"posts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/posts.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Posts = new Mongo.Collection('posts'); /*Posts.allow({                                                            // 1
                                         insert: function(userId, doc) {                                          //
                                           // autoriser les posts seulement si l'utilisateur est authentifié      //
                                           return !! userId;                                                      //
                                         }                                                                        //
                                        });*/                                                                     //
Posts.allow({                                                                                                     // 10
  update: function (userId, post) {                                                                               // 12
    return ownsDocument(userId, post);                                                                            // 12
  },                                                                                                              // 12
  remove: function (userId, post) {                                                                               // 13
    return ownsDocument(userId, post);                                                                            // 13
  }                                                                                                               // 13
});                                                                                                               // 10
Meteor.users.allow({                                                                                              // 16
  update: function (userId, post) {                                                                               // 17
    return true;                                                                                                  // 17
  }                                                                                                               // 17
}); /*var errors = validatePost(postAttributes);                                                                  // 16
        if (errors.post_title || errors.post_content)                                                             //
          throw new Meteor.Error('invalid-post', "You must set a title and URL for your post");*/                 //
Meteor.methods({                                                                                                  // 24
  postInsert: function (postAttributes) {                                                                         // 25
    /*check(Meteor.userId(), String);                                                                             // 26
    check(postAttributes, {                                                                                       //
        post_title: String,                                                                                       //
        post_content: String,                                                                                     //
        categorie: String                                                                                         //
    });*/var user = Meteor.user();                                                                                //
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 33
      post_author: user._id,                                                                                      // 34
      author_name: user.username,                                                                                 // 35
      gender: user.profile.gender,                                                                                // 36
      post_date: new Date(),                                                                                      // 37
      upvoters: [],                                                                                               // 38
      votes: 0                                                                                                    // 39
    });                                                                                                           // 33
                                                                                                                  //
    var postId = Posts.insert(post);                                                                              // 41
    return {                                                                                                      // 42
      _id: postId                                                                                                 // 43
    };                                                                                                            // 42
  },                                                                                                              // 45
  upvote1: function (postId) {                                                                                    // 47
    check(this.userId, String);                                                                                   // 48
    check(postId, String);                                                                                        // 49
    var post = Posts.findOne(postId);                                                                             // 50
    if (!post) throw new Meteor.Error('invalid', 'Post not found');                                               // 51
    if (_.include(post.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');    // 53
    Posts.update(post._id, {                                                                                      // 55
      $addToSet: {                                                                                                // 56
        upvoters: this.userId                                                                                     // 56
      },                                                                                                          // 56
      $inc: {                                                                                                     // 57
        votes: -1                                                                                                 // 57
      }                                                                                                           // 57
    });                                                                                                           // 55
  }                                                                                                               // 59
});                                                                                                               // 24
                                                                                                                  //
validatePost = function (post) {                                                                                  // 63
  var errors = {};                                                                                                // 64
  if (!post.post_title) errors.title = "Please fill in a headline";                                               // 65
  if (!post.content) errors.url = "Please fill in a URL";                                                         // 67
  return errors;                                                                                                  // 69
};                                                                                                                // 70
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rejoindre.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/rejoindre.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Rejoindre = new Mongo.Collection('rejoindre');                                                                    // 1
Rejoindre.allow({                                                                                                 // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    rejoindre: function (postAttributes) {                                                                        // 10
        var user = Meteor.user();                                                                                 // 11
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 12
            user_id: user._id,                                                                                    // 13
            username: user.username,                                                                              // 14
            gender: user.profile.gender,                                                                          // 15
            date: new Date()                                                                                      // 16
        });                                                                                                       // 12
                                                                                                                  //
        var postId = Rejoindre.insert(post);                                                                      // 18
        return {                                                                                                  // 19
            _id: postId                                                                                           // 20
        };                                                                                                        // 19
    }                                                                                                             // 22
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/request.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Requests = new Mongo.Collection('requests');                                                                      // 1
Requests.allow({                                                                                                  // 3
    update: function () {                                                                                         // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function () {                                                                                         // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    demande_ami: function (postAttributes) {                                                                      // 10
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            date: new Date()                                                                                      // 14
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Requests.insert(post);                                                                       // 16
        createFriendsNotification(post);                                                                          // 17
        return {                                                                                                  // 18
            _id: postId                                                                                           // 19
        };                                                                                                        // 18
    },                                                                                                            // 21
    delete_request: function (postAttributes) {                                                                   // 23
        var user = Meteor.userId();                                                                               // 24
                                                                                                                  //
        var post = _.extend(postAttributes, {});                                                                  // 25
                                                                                                                  //
        Requests.remove({                                                                                         // 29
            "from_id": post.from_id,                                                                              // 29
            "to_id": user                                                                                         // 29
        });                                                                                                       // 29
        Requests.remove({                                                                                         // 30
            "from_id": user,                                                                                      // 30
            "to_id": post.from_id                                                                                 // 30
        });                                                                                                       // 30
    }                                                                                                             // 31
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/user.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Mongo = void 0;                                                                                               // 1
module.watch(require("meteor/mongo"), {                                                                           // 1
  Mongo: function (v) {                                                                                           // 1
    Mongo = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
Meteor.users.allow({                                                                                              // 2
  /*update: function(userId, post) { return ownsDocument(userId, post); },*/remove: function (userId) {           // 4
    return true;                                                                                                  // 5
  }                                                                                                               // 5
});                                                                                                               // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userBloquer_IP.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/userBloquer_IP.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer_IP = new Mongo.Collection('user_bloquer_IP');                                                         // 1
UserBloquer_IP.allow({                                                                                            // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    bloquerUser_IP: function (postAttributes) {                                                                   // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = UserBloquer_IP.insert(post);                                                                 // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"visites.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/visites.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Visites = new Mongo.Collection('visites');                                                                        // 1
Visites.allow({                                                                                                   // 3
    update: function (userId) {                                                                                   // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId) {                                                                                   // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    add_visites: function (postAttributes) {                                                                      // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date()                                                                                 // 12
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Visites.insert(post);                                                                        // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    }                                                                                                             // 20
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"permission.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/permission.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// check that the userId specified owns the documents                                                             // 1
ownsDocument = function (userId, doc) {                                                                           // 2
  //return doc && doc.userId === userId;                                                                          // 3
  return 1 === 1;                                                                                                 // 4
};                                                                                                                // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/router.js                                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Router.configure({                                                                                                // 1
  layoutTemplate: 'layout',                                                                                       // 2
  loadingTemplate: 'loading',                                                                                     // 3
  notFoundTemplate: 'notFound',                                                                                   // 4
  waitOn: function () {                                                                                           // 5
    var my_id = Meteor.userId();                                                                                  // 6
    return [/*Meteor.subscribe('notifications'),*/ /*Meteor.subscribe('requests'),*/ /*Meteor.subscribe('chat_notif'),*/Meteor.subscribe('userStatus'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user'), Meteor.subscribe('alertes'), Meteor.subscribe('delete_alertes'), Meteor.subscribe('lastlogin'), Meteor.subscribe('password'), Meteor.subscribe('conseilleres'), /*Meteor.subscribe('posts'),*/ /*Meteor.subscribe('comments'),*/ /*Meteor.subscribe('histoires'),*/ /*Meteor.subscribe('friends'),*/ /*Meteor.subscribe('userBloquer'),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            Meteor.subscribe('contact_Chat'),*/ /*Meteor.subscribe('userIP'),*/ /*Meteor.subscribe('visites'),*/Meteor.subscribe('commentaires')];
  }                                                                                                               // 34
});                                                                                                               // 1
PostsListController = RouteController.extend({                                                                    // 40
  template: 'postsList',                                                                                          // 41
  increment: 5,                                                                                                   // 42
  postsLimit: function () {                                                                                       // 44
    return parseInt(this.params.postsLimit) || this.increment;                                                    // 45
  },                                                                                                              // 46
  findOptions: function () {                                                                                      // 47
    return {                                                                                                      // 48
      sort: {                                                                                                     // 48
        post_date: -1                                                                                             // 48
      },                                                                                                          // 48
      limit: this.postsLimit()                                                                                    // 48
    };                                                                                                            // 48
  },                                                                                                              // 49
  subscriptions: function () {                                                                                    // 50
    this.postsSub = Meteor.subscribe('posts', this.findOptions());                                                // 51
  },                                                                                                              // 52
  posts: function () {                                                                                            // 53
    return Posts.find({}, this.findOptions());                                                                    // 55
  },                                                                                                              // 56
  data: function () {                                                                                             // 57
    var hasMore = this.posts().count() === this.postsLimit();                                                     // 58
    var nextPath = this.route.path({                                                                              // 59
      postsLimit: this.postsLimit() + this.increment                                                              // 59
    });                                                                                                           // 59
    return {                                                                                                      // 60
      posts: this.posts(),                                                                                        // 61
      ready: this.postsSub.ready,                                                                                 // 62
      nextPath: hasMore ? nextPath : null                                                                         // 63
    };                                                                                                            // 60
  },                                                                                                              // 65
  waitOn: function () {                                                                                           // 66
    return [Meteor.subscribe('comments'), Meteor.subscribe('contact_Chat_profil')];                               // 67
  }                                                                                                               // 73
});                                                                                                               // 40
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 78
  // google analytic                                                                                              // 78
  Router.plugin('reywood:iron-router-ga');                                                                        // 79
  Router.configure({                                                                                              // 80
    trackPageView: true                                                                                           // 81
  });                                                                                                             // 80
}                                                                                                                 // 83
                                                                                                                  //
Router.route('/', function () {                                                                                   // 86
  this.redirect('/index');                                                                                        // 87
});                                                                                                               // 88
Router.route('index/:postsLimit?', {                                                                              // 90
  name: 'postsList'                                                                                               // 91
}); /*Router.route('/index/:postsLimit?', {                                                                       // 90
    name: 'postsList',                                                                                            //
    template: 'postsList',                                                                                        //
    waitOn: function() {                                                                                          //
        return  [                                                                                                 //
        Meteor.subscribe('posts'),                                                                                //
        ];                                                                                                        //
         },                                                                                                       //
      data: function() {                                                                                          //
       return Posts.find();                                                                                       //
        },                                                                                                        //
    });*/                                                                                                         //
Router.route('/posts/:_id', {                                                                                     // 107
  name: 'postPage',                                                                                               // 108
  template: 'postPage',                                                                                           // 109
  waitOn: function () {                                                                                           // 110
    return [Meteor.subscribe('Singleposts', this.params._id), Meteor.subscribe('comments', this.params._id), Meteor.subscribe('favoris')];
  },                                                                                                              // 116
  data: function () {                                                                                             // 117
    return Posts.findOne(this.params._id);                                                                        // 118
  }                                                                                                               // 119
});                                                                                                               // 107
Router.route('/posts_mobile/:_id', {                                                                              // 123
  name: 'postPage_mobile',                                                                                        // 124
  template: 'postPage_mobile',                                                                                    // 125
  waitOn: function () {                                                                                           // 126
    return [Meteor.subscribe('Singleposts', this.params._id), Meteor.subscribe('comments', this.params._id), Meteor.subscribe('favoris')];
  },                                                                                                              // 132
  data: function () {                                                                                             // 133
    return Posts.findOne(this.params._id);                                                                        // 134
  }                                                                                                               // 135
});                                                                                                               // 123
Router.route('/posts/:_id/edit', {                                                                                // 139
  name: 'postEdit',                                                                                               // 140
  data: function () {                                                                                             // 141
    return Posts.findOne(this.params._id);                                                                        // 142
  },                                                                                                              // 143
  waitOn: function () {                                                                                           // 144
    return [Meteor.subscribe('Singleposts', this.params._id)];                                                    // 145
  }                                                                                                               // 148
});                                                                                                               // 139
Router.route('/contact', {                                                                                        // 151
  name: 'contact',                                                                                                // 152
  template: 'contact'                                                                                             // 153
});                                                                                                               // 151
Router.route('/profil/:post_author?', {                                                                           // 157
  name: 'profil',                                                                                                 // 158
  template: 'profil',                                                                                             // 159
  data: function () {                                                                                             // 160
    return Meteor.users.findOne(this.params.post_author);                                                         // 161
  },                                                                                                              // 162
  waitOn: function () {                                                                                           // 163
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user'), Meteor.subscribe('favoris')];
  }                                                                                                               // 175
});                                                                                                               // 157
Router.route('/profil/:_id', {                                                                                    // 180
  name: 'mon_profil',                                                                                             // 181
  template: 'profil',                                                                                             // 182
  waitOn: function () {                                                                                           // 183
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user')];
  }                                                                                                               // 194
});                                                                                                               // 180
Router.route('/messagerie/:post_author?', {                                                                       // 197
  name: 'messagerie',                                                                                             // 198
  template: 'messagerie',                                                                                         // 199
  waitOn: function () {                                                                                           // 200
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat'), Meteor.subscribe('favoris')];
  },                                                                                                              // 207
  data: function () {                                                                                             // 208
    return Meteor.users.findOne(this.params.post_author);                                                         // 209
  }                                                                                                               // 210
});                                                                                                               // 197
Router.route('/messagerie_vierge/:post_author?', {                                                                // 216
  name: 'messagerie_vierge',                                                                                      // 217
  template: 'messagerie_vierge',                                                                                  // 218
  data: function () {                                                                                             // 219
    return Meteor.users.findOne(this.params.post_author);                                                         // 220
  },                                                                                                              // 221
  waitOn: function () {                                                                                           // 222
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat'), Meteor.subscribe('favoris')];
  }                                                                                                               // 229
});                                                                                                               // 216
Router.route('/messagerie_mobile/:post_author?', {                                                                // 234
  name: 'messagerie_mobile',                                                                                      // 235
  template: 'messagerie_mobile',                                                                                  // 236
  data: function () {                                                                                             // 237
    return Meteor.users.findOne(this.params.post_author);                                                         // 238
  },                                                                                                              // 239
  waitOn: function () {                                                                                           // 240
    return [Meteor.subscribe('chat', this.params.post_author), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat'), Meteor.subscribe('favoris')];
  }                                                                                                               // 247
});                                                                                                               // 234
Router.route('/mot_de_passe', {                                                                                   // 251
  name: 'mot_de_passe',                                                                                           // 252
  template: 'mot_de_passe'                                                                                        // 253
});                                                                                                               // 251
Router.route('/signaler_bug', {                                                                                   // 257
  name: 'signaler_bug',                                                                                           // 258
  template: 'signaler_bug'                                                                                        // 259
});                                                                                                               // 257
Router.route('/ameliore_site', {                                                                                  // 263
  name: 'ameliore_site',                                                                                          // 264
  template: 'ameliore_site'                                                                                       // 265
});                                                                                                               // 263
Router.route('/supprimer_compte', {                                                                               // 269
  name: 'supprimer_compte',                                                                                       // 270
  template: 'supprimer_compte'                                                                                    // 271
});                                                                                                               // 269
Router.route('/inscription', {                                                                                    // 275
  name: 'inscription',                                                                                            // 276
  template: 'inscription'                                                                                         // 277
});                                                                                                               // 275
Router.route('/devenir_conseillere', {                                                                            // 281
  name: 'devenir_conseillere',                                                                                    // 282
  template: 'devenir_conseillere'                                                                                 // 283
});                                                                                                               // 281
Router.route('/devenir_conseillere_mobile', {                                                                     // 287
  name: 'devenir_conseillere_mobile',                                                                             // 288
  template: 'devenir_conseillere_mobile'                                                                          // 289
});                                                                                                               // 287
Router.route('/confirmation_conseillere', {                                                                       // 293
  name: 'confirmation_conseillere',                                                                               // 294
  template: 'confirmation_conseillere'                                                                            // 295
});                                                                                                               // 293
Router.route('/confirmation_conseillere_mobile', {                                                                // 298
  name: 'confirmation_conseillere_mobile',                                                                        // 299
  template: 'confirmation_conseillere_mobile'                                                                     // 300
});                                                                                                               // 298
Router.route('/recherche_conseillere', {                                                                          // 303
  name: 'recherche_conseillere',                                                                                  // 304
  template: 'recherche_conseillere'                                                                               // 305
});                                                                                                               // 303
Router.route('/recherche_mobile', {                                                                               // 309
  name: 'recherche_mobile',                                                                                       // 310
  template: 'recherche_mobile'                                                                                    // 311
});                                                                                                               // 309
Router.route('/resultat_conseillere/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sport?/:mode?/:sante?/:beaute?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere',                                                                                   // 316
  template: 'resultat_conseillere',                                                                               // 317
  data: function () {                                                                                             // 318
    return Conseilleres.find();                                                                                   // 319
  }                                                                                                               // 320
});                                                                                                               // 315
Router.route('/resultat_conseillere_mobile/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sport?/:mode?/:sante?/:beaute?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere_mobile',                                                                            // 325
  template: 'resultat_conseillere_mobile',                                                                        // 326
  data: function () {                                                                                             // 327
    return Conseilleres.find();                                                                                   // 328
  }                                                                                                               // 329
});                                                                                                               // 324
Router.route('/classement-conseilleres', {                                                                        // 333
  name: 'classementComplet',                                                                                      // 334
  template: 'classementComplet' /*waitOn: function() {                                                            // 335
                                  return Meteor.subscribe('conseilleres');                                        //
                                   }*/                                                                            //
});                                                                                                               // 333
Router.route('/classement-conseilleres-mobile', {                                                                 // 341
  name: 'classementComplet_mobile',                                                                               // 342
  template: 'classementComplet_mobile'                                                                            // 343
});                                                                                                               // 341
Router.route('/conseiller_online', {                                                                              // 346
  name: 'conseiller_online',                                                                                      // 347
  template: 'conseiller_online'                                                                                   // 348
});                                                                                                               // 346
Router.route('/conseiller_online_mobile', {                                                                       // 352
  name: 'conseiller_online_mobile',                                                                               // 353
  template: 'conseiller_online_mobile'                                                                            // 354
});                                                                                                               // 352
Router.route('/user_online', {                                                                                    // 358
  name: 'user_online',                                                                                            // 359
  template: 'user_online'                                                                                         // 360
});                                                                                                               // 358
Router.route('/conseiller/:post_author?', {                                                                       // 363
  name: 'presentation_conseiller',                                                                                // 364
  template: 'presentation_conseiller',                                                                            // 365
  data: function () {                                                                                             // 366
    return Meteor.users.findOne(this.params.post_author);                                                         // 367
  },                                                                                                              // 368
  waitOn: function () {                                                                                           // 369
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 381
});                                                                                                               // 363
Router.route('/favoris/:post_author?', {                                                                          // 384
  name: 'mes_favoris',                                                                                            // 385
  template: 'mes_favoris',                                                                                        // 386
  data: function () {                                                                                             // 387
    return Meteor.users.findOne(this.params.post_author);                                                         // 388
  },                                                                                                              // 389
  waitOn: function () {                                                                                           // 390
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 402
});                                                                                                               // 384
Router.route('/favoris_mobile/:post_author?', {                                                                   // 405
  name: 'favoris_mobile',                                                                                         // 406
  template: 'favoris_mobile',                                                                                     // 407
  data: function () {                                                                                             // 408
    return Meteor.users.findOne(this.params.post_author);                                                         // 409
  },                                                                                                              // 410
  waitOn: function () {                                                                                           // 411
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 423
});                                                                                                               // 405
Router.route('/presentation_conseiller_mobile/:post_author?', {                                                   // 427
  name: 'presentation_conseiller_mobile',                                                                         // 428
  template: 'presentation_conseiller_mobile',                                                                     // 429
  data: function () {                                                                                             // 430
    return Meteor.users.findOne(this.params.post_author);                                                         // 431
  }                                                                                                               // 431
});                                                                                                               // 427
Router.route('/histoire/:post_author?', {                                                                         // 436
  name: 'histoire',                                                                                               // 437
  template: 'histoire',                                                                                           // 438
  data: function () {                                                                                             // 439
    return Meteor.users.findOne(this.params.post_author);                                                         // 440
  },                                                                                                              // 441
  waitOn: function () {                                                                                           // 442
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 453
});                                                                                                               // 436
Router.route('/histoire_mobile/:post_author?', {                                                                  // 456
  name: 'histoire_mobile',                                                                                        // 457
  template: 'histoire_mobile',                                                                                    // 458
  data: function () {                                                                                             // 459
    return Meteor.users.findOne(this.params.post_author);                                                         // 460
  },                                                                                                              // 461
  waitOn: function () {                                                                                           // 462
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 473
});                                                                                                               // 456
Router.route('/amis/:post_author?', {                                                                             // 476
  name: 'amis',                                                                                                   // 477
  template: 'amis',                                                                                               // 478
  data: function () {                                                                                             // 479
    return Meteor.users.findOne(this.params.post_author);                                                         // 480
  },                                                                                                              // 481
  waitOn: function () {                                                                                           // 482
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 493
});                                                                                                               // 476
Router.route('/visites/:post_author?', {                                                                          // 496
  name: 'visites',                                                                                                // 497
  template: 'visites',                                                                                            // 498
  data: function () {                                                                                             // 499
    return Meteor.users.findOne(this.params.post_author);                                                         // 500
  },                                                                                                              // 501
  waitOn: function () {                                                                                           // 502
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 513
});                                                                                                               // 496
Router.route('/mon_compte/:post_author?', {                                                                       // 516
  name: 'mon_compte',                                                                                             // 517
  template: 'mon_compte',                                                                                         // 518
  data: function () {                                                                                             // 519
    return Meteor.users.findOne(this.params.post_author);                                                         // 520
  }                                                                                                               // 521
});                                                                                                               // 516
Router.route('/compte_bancaire/:post_author?', {                                                                  // 525
  name: 'compte_bancaire',                                                                                        // 526
  template: 'compte_bancaire',                                                                                    // 527
  data: function () {                                                                                             // 528
    return Meteor.users.findOne(this.params.post_author);                                                         // 529
  }                                                                                                               // 530
});                                                                                                               // 525
Router.route('/visites_mobile/:post_author?', {                                                                   // 534
  name: 'visites_mobile',                                                                                         // 535
  template: 'visites_mobile',                                                                                     // 536
  data: function () {                                                                                             // 537
    return Meteor.users.findOne(this.params.post_author);                                                         // 538
  },                                                                                                              // 539
  waitOn: function () {                                                                                           // 540
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 551
});                                                                                                               // 534
Router.route('/personne_aide/:post_author?', {                                                                    // 554
  name: 'personne_aide',                                                                                          // 555
  template: 'personne_aide',                                                                                      // 556
  data: function () {                                                                                             // 557
    return Meteor.users.findOne(this.params.post_author);                                                         // 558
  },                                                                                                              // 559
  waitOn: function () {                                                                                           // 560
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 571
});                                                                                                               // 554
Router.route('/personne_aide_mobile/:post_author?', {                                                             // 574
  name: 'personne_aide_mobile',                                                                                   // 575
  template: 'personne_aide_mobile',                                                                               // 576
  data: function () {                                                                                             // 577
    return Meteor.users.findOne(this.params.post_author);                                                         // 578
  },                                                                                                              // 579
  waitOn: function () {                                                                                           // 580
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 591
});                                                                                                               // 574
Router.route('/messages_poste/:post_author?', {                                                                   // 594
  name: 'messages_poste',                                                                                         // 595
  template: 'messages_poste',                                                                                     // 596
  data: function () {                                                                                             // 597
    return Meteor.users.findOne(this.params.post_author);                                                         // 598
  },                                                                                                              // 599
  waitOn: function () {                                                                                           // 600
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 611
});                                                                                                               // 594
Router.route('/messages_poste_mobile/:post_author?', {                                                            // 614
  name: 'messages_poste_mobile',                                                                                  // 615
  template: 'messages_poste_mobile',                                                                              // 616
  data: function () {                                                                                             // 617
    return Meteor.users.findOne(this.params.post_author);                                                         // 618
  },                                                                                                              // 619
  waitOn: function () {                                                                                           // 620
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 631
});                                                                                                               // 614
Router.route('/commentaires/:post_author?', {                                                                     // 634
  name: 'commentaires',                                                                                           // 635
  template: 'commentaires',                                                                                       // 636
  data: function () {                                                                                             // 637
    return Meteor.users.findOne(this.params.post_author);                                                         // 638
  } /*waitOn: function() {                                                                                        // 639
      return [                                                                                                    //
      Meteor.subscribe('posts'),                                                                                  //
      Meteor.subscribe('comments'),                                                                               //
      Meteor.subscribe('histoires'),                                                                              //
      Meteor.subscribe('friends'),                                                                                //
      Meteor.subscribe('visites'),                                                                                //
      Meteor.subscribe('commentaires'),                                                                           //
      Meteor.subscribe('messages_signaler'),                                                                      //
      Meteor.subscribe('favoris'),                                                                                //
       ];                                                                                                         //
       },*/                                                                                                       //
});                                                                                                               // 634
Router.route('/commentaires_mobile/:post_author?', {                                                              // 654
  name: 'commentaires_mobile',                                                                                    // 655
  template: 'commentaires_mobile',                                                                                // 656
  data: function () {                                                                                             // 657
    return Meteor.users.findOne(this.params.post_author);                                                         // 658
  },                                                                                                              // 659
  waitOn: function () {                                                                                           // 660
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 671
});                                                                                                               // 654
Router.route('/rediger_commentaires_mobile/:post_author?', {                                                      // 674
  name: 'rediger_commentaires_mobile',                                                                            // 675
  template: 'rediger_commentaires_mobile',                                                                        // 676
  data: function () {                                                                                             // 677
    return Meteor.users.findOne(this.params.post_author);                                                         // 678
  },                                                                                                              // 679
  waitOn: function () {                                                                                           // 680
    return Meteor.subscribe('commentaires');                                                                      // 681
  }                                                                                                               // 682
});                                                                                                               // 674
Router.route('/ils_ont_aide/:post_author?', {                                                                     // 685
  name: 'ils_ont_aide',                                                                                           // 686
  template: 'ils_ont_aide',                                                                                       // 687
  data: function () {                                                                                             // 688
    return Meteor.users.findOne(this.params.post_author);                                                         // 689
  },                                                                                                              // 690
  waitOn: function () {                                                                                           // 691
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 702
});                                                                                                               // 685
Router.route('/ils_ont_aide_mobile/:post_author?', {                                                              // 705
  name: 'ils_ont_aide_mobile',                                                                                    // 706
  template: 'ils_ont_aide_mobile',                                                                                // 707
  data: function () {                                                                                             // 708
    return Meteor.users.findOne(this.params.post_author);                                                         // 709
  },                                                                                                              // 710
  waitOn: function () {                                                                                           // 711
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 722
});                                                                                                               // 705
Router.route('/alerte/:post_author?', {                                                                           // 725
  name: 'alerte',                                                                                                 // 726
  template: 'alerte',                                                                                             // 727
  data: function () {                                                                                             // 728
    return Meteor.users.findOne(this.params.post_author);                                                         // 729
  },                                                                                                              // 730
  waitOn: function () {                                                                                           // 731
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 742
});                                                                                                               // 725
Router.route('/avertissement/:post_author?', {                                                                    // 745
  name: 'avertissement',                                                                                          // 746
  template: 'avertissement',                                                                                      // 747
  data: function () {                                                                                             // 748
    return Meteor.users.findOne(this.params.post_author);                                                         // 749
  },                                                                                                              // 750
  waitOn: function () {                                                                                           // 751
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 762
});                                                                                                               // 745
Router.route('/avertissement_mobile/:post_author?', {                                                             // 765
  name: 'avertissement_mobile',                                                                                   // 766
  template: 'avertissement_mobile',                                                                               // 767
  data: function () {                                                                                             // 768
    return Meteor.users.findOne(this.params.post_author);                                                         // 769
  },                                                                                                              // 770
  waitOn: function () {                                                                                           // 771
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 782
});                                                                                                               // 765
Router.route('/add_commentaire_mobile/:post_author?', {                                                           // 785
  name: 'add_commentaire_mobile',                                                                                 // 786
  template: 'add_commentaire_mobile',                                                                             // 787
  data: function () {                                                                                             // 788
    return Meteor.users.findOne(this.params.post_author);                                                         // 789
  }                                                                                                               // 789
});                                                                                                               // 785
Router.route('/valider_commentaire_mobile/:post_author?', {                                                       // 792
  name: 'valider_commentaire_mobile',                                                                             // 793
  template: 'valider_commentaire_mobile',                                                                         // 794
  data: function () {                                                                                             // 795
    return Meteor.users.findOne(this.params.post_author);                                                         // 796
  }                                                                                                               // 796
});                                                                                                               // 792
Router.route('/presentation/:post_author?', {                                                                     // 799
  name: 'presentation',                                                                                           // 800
  template: 'presentation',                                                                                       // 801
  data: function () {                                                                                             // 802
    return Meteor.users.findOne(this.params.post_author);                                                         // 803
  },                                                                                                              // 804
  waitOn: function () {                                                                                           // 805
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 816
});                                                                                                               // 799
Router.route('/alertes_mobile/:post_author?', {                                                                   // 819
  name: 'alertes_mobile',                                                                                         // 820
  template: 'alertes_mobile',                                                                                     // 821
  data: function () {                                                                                             // 822
    return Meteor.users.findOne(this.params.post_author);                                                         // 823
  }                                                                                                               // 823
});                                                                                                               // 819
Router.route('/creerAlerte/:post_author?', {                                                                      // 826
  name: 'creerAlerte',                                                                                            // 827
  template: 'creerAlerte',                                                                                        // 828
  data: function () {                                                                                             // 829
    return Meteor.users.findOne(this.params.post_author);                                                         // 830
  }                                                                                                               // 830
});                                                                                                               // 826
Router.route('/valider_Alerte/:post_author?', {                                                                   // 833
  name: 'valider_Alerte',                                                                                         // 834
  template: 'valider_Alerte',                                                                                     // 835
  data: function () {                                                                                             // 836
    return Meteor.users.findOne(this.params.post_author);                                                         // 837
  }                                                                                                               // 837
});                                                                                                               // 833
Router.route('/presentation_mobile/:post_author?', {                                                              // 840
  name: 'presentation_mobile',                                                                                    // 841
  template: 'presentation_mobile',                                                                                // 842
  data: function () {                                                                                             // 843
    return Meteor.users.findOne(this.params.post_author);                                                         // 844
  }                                                                                                               // 844
});                                                                                                               // 840
Router.route('/notifications_mobile', {                                                                           // 847
  name: 'notifications_mobile',                                                                                   // 848
  template: 'notifications_mobile1'                                                                               // 849
});                                                                                                               // 847
Router.route('/profil_mobile/:post_author?', {                                                                    // 853
  name: 'profil_mobile',                                                                                          // 854
  template: 'profil_mobile',                                                                                      // 855
  data: function () {                                                                                             // 856
    return Meteor.users.findOne(this.params.post_author);                                                         // 857
  },                                                                                                              // 858
  waitOn: function () {                                                                                           // 859
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 870
});                                                                                                               // 853
Router.route('/amis_mobile/:post_author?', {                                                                      // 873
  name: 'amis_mobile',                                                                                            // 874
  template: 'amis_mobile',                                                                                        // 875
  data: function () {                                                                                             // 876
    return Meteor.users.findOne(this.params.post_author);                                                         // 877
  },                                                                                                              // 878
  waitOn: function () {                                                                                           // 879
    return [Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('friends'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('favoris')];
  }                                                                                                               // 890
});                                                                                                               // 873
Router.route('/connexion_mobile', {                                                                               // 894
  name: 'connexion_mobile',                                                                                       // 895
  template: 'connexion_mobile'                                                                                    // 896
});                                                                                                               // 894
Router.route('/supprimer_mon_compte', {                                                                           // 899
  name: 'supprimer_mon_compte',                                                                                   // 900
  template: 'supprimer_mon_compte'                                                                                // 901
});                                                                                                               // 899
Router.route('/dashboard', {                                                                                      // 904
  name: 'dashboard',                                                                                              // 905
  template: 'dashboard'                                                                                           // 906
});                                                                                                               // 904
Router.route('/dons', {                                                                                           // 909
  name: 'dons',                                                                                                   // 910
  template: 'dons'                                                                                                // 911
});                                                                                                               // 909
Router.route('/cgu', {                                                                                            // 914
  name: 'cgu',                                                                                                    // 915
  template: 'cgu'                                                                                                 // 916
});                                                                                                               // 914
Router.route('/numero', {                                                                                         // 919
  name: 'numero',                                                                                                 // 920
  template: 'numero'                                                                                              // 921
});                                                                                                               // 919
Router.route('/rejoindre', {                                                                                      // 924
  name: 'rejoindre',                                                                                              // 925
  template: 'rejoindre'                                                                                           // 926
});                                                                                                               // 924
Router.route('/confirmation-rejoindre', {                                                                         // 929
  name: 'confirmation_rejoindre',                                                                                 // 930
  template: 'confirmation_rejoindre'                                                                              // 931
});                                                                                                               // 929
Router.route('/poeme', {                                                                                          // 934
  name: 'poeme',                                                                                                  // 935
  template: 'poeme'                                                                                               // 936
}); /*Router.route('/le_secret_de_cendrillon', function() {                                                       // 934
        var filePath = process.env.PWD + "/server/le_secret_de_cendrillon.pdf";                                   //
        var fs = Meteor.npmRequire('fs');                                                                         //
        var data = fs.readFileSync(filePath);                                                                     //
        this.response.write(data);                                                                                //
        this.response.end();                                                                                      //
    }, {                                                                                                          //
        where: 'server'                                                                                           //
    });*/                                                                                                         //
Router.route('/le_secret_de_cendrillon', {                                                                        // 949
  name: 'le_secret_de_cendrillon',                                                                                // 950
  template: 'le_secret_de_cendrillon'                                                                             // 951
});                                                                                                               // 949
Router.onBeforeAction('dataNotFound', {                                                                           // 954
  only: 'postPage'                                                                                                // 954
});                                                                                                               // 954
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixture.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/fixture.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
  Meteor: function (v) {                                                                                          // 1
    Meteor = v;                                                                                                   // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
module.watch(require("meteor/houston:admin"));                                                                    // 1
Houston.add_collection(Meteor.users);                                                                             // 6
Houston.add_collection(Houston._admins); /*var now = new Date().getTime();                                        // 7
                                           // crée deux utilisateurs                                              //
                                          var tomId = Meteor.users.insert({                                       //
                                            profile: { name: 'Tom Coleman' }                                      //
                                          });                                                                     //
                                          var tom = Meteor.users.findOne(tomId);                                  //
                                          var sachaId = Meteor.users.insert({                                     //
                                            profile: { name: 'Sacha Greif' }                                      //
                                          });                                                                     //
                                          var sacha = Meteor.users.findOne(sachaId);                              //
                                           var telescopeId = Posts.insert({                                       //
                                            post_title: 'Introducing Telescope',                                  //
                                            post_author: sacha._id,                                               //
                                            author_name: sacha.profile.name,                                      //
                                            //url: 'http://sachagreif.com/introducing-telescope/',                //
                                            post_date: new Date(now - 7 * 3600 * 1000)                            //
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: tom._id,                                                      //
                                            author: tom.profile.name,                                             //
                                            submitted: new Date(now - 5 * 3600 * 1000),                           //
                                            body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: sacha._id,                                                    //
                                            author: sacha.profile.name,                                           //
                                            submitted: new Date(now - 3 * 3600 * 1000),                           //
                                            body: 'Bien sûr Tom !'                                                //
                                          });                                                                     //
                                           Posts.insert({                                                         //
                                            post_title: 'Meteor',                                                 //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://meteor.com',                                           //
                                            post_date: new Date(now - 10 * 3600 * 1000)                           //
                                          });                                                                     //
                                            Posts.insert({                                                        //
                                            post_title: 'The Meteor Book',                                        //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://themeteorbook.com',                                    //
                                            post_date: new Date(now - 12 * 3600 * 1000)                           //
                                          });*/ /*                                                                //
                                                    var now = new Date().getTime();                               //
                                                                                                                  //
                                                  // Créer deux utilisateurs                                      //
                                                  var tomId = Meteor.users.insert({                               //
                                                    profile: { name: 'Tom Coleman' }                              //
                                                  });                                                             //
                                                  var tom = Meteor.users.findOne(tomId);                          //
                                                  var sachaId = Meteor.users.insert({                             //
                                                    profile: { name: 'Sacha Greif' }                              //
                                                  });                                                             //
                                                  var sacha = Meteor.users.findOne(sachaId);                      //
                                                                                                                  //
                                                  var telescopeId = Posts.insert({                                //
                                                    title: 'Introducing Telescope',                               //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    url: 'http://sachagreif.com/introducing-telescope/',          //
                                                    submitted: new Date(now - 7 * 3600 * 1000),                   //
                                                    commentsCount: 2,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    submitted: new Date(now - 5 * 3600 * 1000),                   //
                                                    body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    submitted: new Date(now - 3 * 3600 * 1000),                   //
                                                    body: 'Bien sûr Tom !'                                        //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'Meteor',                                              //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://meteor.com',                                     //
                                                    submitted: new Date(now - 10 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'The Meteor Book',                                     //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://themeteorbook.com',                              //
                                                    submitted: new Date(now - 12 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  for (var i = 0; i < 10; i++) {                                  //
                                                    Posts.insert({                                                //
                                                      title: 'Test post #' + i,                                   //
                                                      author: sacha.profile.name,                                 //
                                                      userId: sacha._id,                                          //
                                                      url: 'http://google.com/?q=test-' + i,                      //
                                                      submitted: new Date(now - i * 3600 * 1000 + 1),             //
                                                      commentsCount: 0,                                           //
                                                      upvoters: [],                                               //
                                                      votes: 0                                                    //
                                                    });                                                           //
                                                  }                                                               //
                                                */                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/items.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("items", function () {                                                                             // 1
  if (Roles.userIsInRole(this.userId, 'paid')) {                                                                  // 2
    return Items.find();                                                                                          // 3
  }                                                                                                               // 4
});                                                                                                               // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methodes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methodes.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publication.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publication.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish('posts', function (options) {                                                                      // 1
  return Posts.find({}, options);                                                                                 // 2
});                                                                                                               // 3
Meteor.publish('Singleposts', function (id) {                                                                     // 6
  return Posts.find(id);                                                                                          // 7
});                                                                                                               // 8
Meteor.publish('users', function () {                                                                             // 11
  return Meteors.users.find();                                                                                    // 12
});                                                                                                               // 13
Meteor.publish('comments', function () {                                                                          // 16
  return Comments.find();                                                                                         // 17
});                                                                                                               // 18
Meteor.publish('notifications', function () {                                                                     // 21
  var my_id = Meteor.userId();                                                                                    // 22
  return Notifications.find({                                                                                     // 23
    userId: my_id,                                                                                                // 23
    read: false                                                                                                   // 23
  });                                                                                                             // 23
});                                                                                                               // 24
Meteor.publish('histoires', function () {                                                                         // 26
  return Histoires.find();                                                                                        // 27
});                                                                                                               // 28
Meteor.publish('requests', function () {                                                                          // 30
  var my_id = Meteor.userId();                                                                                    // 31
  return Requests.find({                                                                                          // 32
    to_id: my_id                                                                                                  // 32
  });                                                                                                             // 32
});                                                                                                               // 33
Meteor.publish('friends', function () {                                                                           // 35
  return Friends.find();                                                                                          // 36
});                                                                                                               // 37
Meteor.publish('chat', function (id) {                                                                            // 39
  var my_id = Meteor.userId();                                                                                    // 40
  return Chat.find({                                                                                              // 41
    $or: [{                                                                                                       // 41
      from_id: id,                                                                                                // 41
      to_id: my_id                                                                                                // 41
    }, {                                                                                                          // 41
      to_id: id,                                                                                                  // 41
      from_id: my_id                                                                                              // 41
    }]                                                                                                            // 41
  });                                                                                                             // 41
});                                                                                                               // 42
Meteor.publish('chat_notif', function () {                                                                        // 45
  var my_id = Meteor.userId();                                                                                    // 46
  return Chat.find({                                                                                              // 47
    $or: [{                                                                                                       // 47
      from_id: my_id                                                                                              // 48
    }, {                                                                                                          // 48
      to_id: my_id                                                                                                // 49
    }]                                                                                                            // 49
  });                                                                                                             // 47
});                                                                                                               // 51
Meteor.publish('userBloquer', function () {                                                                       // 54
  return UserBloquer.find();                                                                                      // 55
});                                                                                                               // 56
Meteor.publish('contact_Chat', function () {                                                                      // 58
  var id = Meteor.userId();                                                                                       // 59
  return ContactChat.find({                                                                                       // 60
    $or: [{                                                                                                       // 60
      from_id: id                                                                                                 // 61
    }, {                                                                                                          // 61
      to_id: id                                                                                                   // 62
    }]                                                                                                            // 62
  });                                                                                                             // 60
});                                                                                                               // 64
Meteor.publish('contact_Chat_profil', function () {                                                               // 66
  return ContactChat.find();                                                                                      // 67
});                                                                                                               // 68
Meteor.publish("userStatus", function () {                                                                        // 70
  return Meteor.users.find({                                                                                      // 71
    "status.online": true                                                                                         // 71
  });                                                                                                             // 71
});                                                                                                               // 72
Meteor.publish("password", function () {                                                                          // 74
  return Meteor.users.find({                                                                                      // 75
    "services.password.bcrypt": true                                                                              // 75
  });                                                                                                             // 75
});                                                                                                               // 76
Meteor.publish("visites", function () {                                                                           // 79
  return Visites.find();                                                                                          // 80
});                                                                                                               // 81
Meteor.publish('commentaires', function () {                                                                      // 83
  return Commentaires.find();                                                                                     // 84
});                                                                                                               // 85
Meteor.publish('messages_signaler', function () {                                                                 // 87
  return Signaler.find();                                                                                         // 88
});                                                                                                               // 89
Meteor.publish('avertissement_user', function () {                                                                // 91
  return Avertissement.find();                                                                                    // 92
});                                                                                                               // 93
Meteor.publish("userIP", function () {                                                                            // 95
  return Meteor.users.find({}, {                                                                                  // 96
    "status.lastLogin.ipAddr": true                                                                               // 96
  });                                                                                                             // 96
});                                                                                                               // 97
Meteor.publish("lastlogin", function () {                                                                         // 99
  return Meteor.users.find({}, {                                                                                  // 100
    "status.lastLogin.date": true                                                                                 // 100
  });                                                                                                             // 100
});                                                                                                               // 101
Meteor.publish('user_bloquer_IP', function () {                                                                   // 103
  return UserBloquer_IP.find();                                                                                   // 104
});                                                                                                               // 105
Meteor.publish('alertes', function () {                                                                           // 107
  return Alertes.find();                                                                                          // 108
});                                                                                                               // 109
Meteor.publish('delete_alertes', function () {                                                                    // 111
  return DeleteAlertes.find();                                                                                    // 112
});                                                                                                               // 113
Meteor.publish('conseilleres', function () {                                                                      // 115
  return Conseilleres.find();                                                                                     // 116
});                                                                                                               // 116
Meteor.publish('rejoindre', function () {                                                                         // 118
  return Rejoindre.find();                                                                                        // 119
});                                                                                                               // 119
Meteor.publish('conseilleres_right', function () {                                                                // 121
  return Conseilleres.find({}, {                                                                                  // 122
    fields: {                                                                                                     // 123
      gender: 1,                                                                                                  // 124
      username: 1,                                                                                                // 125
      user_id: 1,                                                                                                 // 126
      presentation: 1,                                                                                            // 127
      date: 1,                                                                                                    // 128
      user_id: 1                                                                                                  // 129
    }                                                                                                             // 123
  });                                                                                                             // 122
});                                                                                                               // 131
Meteor.publish('conseilleres_left', function () {                                                                 // 133
  return Conseilleres.find({}, {                                                                                  // 134
    fields: {                                                                                                     // 135
      gender: 1,                                                                                                  // 136
      username: 1,                                                                                                // 137
      indice_confiance: 1,                                                                                        // 138
      user_id: 1                                                                                                  // 139
    }                                                                                                             // 135
  });                                                                                                             // 134
});                                                                                                               // 141
Meteor.publish('favoris', function () {                                                                           // 143
  return Favoris.find();                                                                                          // 144
});                                                                                                               // 145
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
Meteor.startup(function () {                                                                                      // 4
    var today = new Date();                                                                                       // 5
    var targetDate = new Date();                                                                                  // 6
    targetDate.setDate(today.getDate() - 7);                                                                      // 8
    targetDate.setHours(0);                                                                                       // 9
    targetDate.setMinutes(0);                                                                                     // 10
    targetDate.setSeconds(0);                                                                                     // 11
    Posts.remove({                                                                                                // 13
        post_date: {                                                                                              // 13
            $lt: targetDate                                                                                       // 13
        }                                                                                                         // 13
    });                                                                                                           // 13
    Comments.remove({                                                                                             // 14
        submitted: {                                                                                              // 14
            $lt: targetDate                                                                                       // 14
        }                                                                                                         // 14
    });                                                                                                           // 14
    Visites.remove({                                                                                              // 15
        post_date: {                                                                                              // 15
            $lt: targetDate                                                                                       // 15
        }                                                                                                         // 15
    });                                                                                                           // 15
    var targetDate_chat = new Date();                                                                             // 17
    targetDate_chat.setDate(today.getDate() - 30);                                                                // 19
    targetDate_chat.setHours(0);                                                                                  // 20
    targetDate_chat.setMinutes(0);                                                                                // 21
    targetDate_chat.setSeconds(0);                                                                                // 22
    Chat.remove({                                                                                                 // 24
        post_date: {                                                                                              // 24
            $lt: targetDate_chat                                                                                  // 24
        }                                                                                                         // 24
    });                                                                                                           // 24
}); /*Accounts.onCreateUser(function( user) {                                                                     // 27
        /*console.log(user);                                                                                      //
        return user;                                                                                              //
    });*/                                                                                                         //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// mup.js                                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exports = {                                                                                                // 1
  servers: {                                                                                                      // 2
    one: {                                                                                                        // 3
      // TODO: set host address, username, and authentication method                                              // 4
      host: '151.80.146.217',                                                                                     // 5
      username: 'root',                                                                                           // 6
      // pem: './path/to/pem'                                                                                     // 7
      password: 'mT9nQ5Pm' // or neither for authenticate from ssh-agent                                          // 8
                                                                                                                  //
    }                                                                                                             // 3
  },                                                                                                              // 2
  app: {                                                                                                          // 13
    // TODO: change app name and path                                                                             // 14
    name: 'kurbys',                                                                                               // 15
    path: '../kurbys',                                                                                            // 16
    servers: {                                                                                                    // 18
      one: {}                                                                                                     // 19
    },                                                                                                            // 18
    buildOptions: {                                                                                               // 22
      serverOnly: true                                                                                            // 23
    },                                                                                                            // 22
    env: {                                                                                                        // 26
      // TODO: Change to your app's url                                                                           // 27
      // If you are using ssl, it needs to start with https://                                                    // 28
      ROOT_URL: 'https://www.kurbys.com',                                                                         // 29
      MONGO_URL: 'mongodb://151.80.146.217:27017/meteor'                                                          // 30
    },                                                                                                            // 26
    ssl: {                                                                                                        // 33
      // (optional)                                                                                               // 33
      // Enables let's encrypt (optional)                                                                         // 34
      autogenerate: {                                                                                             // 35
        email: 'jbroussat@orange.fr',                                                                             // 36
        // comma separated list of domains                                                                        // 37
        domains: 'kurbys.com,www.kurbys.com'                                                                      // 38
      }                                                                                                           // 35
    },                                                                                                            // 33
    docker: {                                                                                                     // 42
      // change to 'kadirahq/meteord' if your app is using Meteor 1.3 or older                                    // 43
      image: 'abernix/meteord:base'                                                                               // 44
    },                                                                                                            // 42
    // Show progress bar while uploading bundle to server                                                         // 47
    // You might need to disable it on CI servers                                                                 // 48
    enableUploadProgressBar: true                                                                                 // 49
  },                                                                                                              // 13
  mongo: {                                                                                                        // 52
    version: '3.4.9',                                                                                             // 53
    servers: {                                                                                                    // 54
      one: {}                                                                                                     // 55
    }                                                                                                             // 54
  }                                                                                                               // 52
};                                                                                                                // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".coffee"
  ]
});
require("./lib/Collections/Chat.js");
require("./lib/Collections/UserBloquer.js");
require("./lib/Collections/alerte.js");
require("./lib/Collections/avertissement.js");
require("./lib/Collections/comment.js");
require("./lib/Collections/commentaires.js");
require("./lib/Collections/conseilleres.js");
require("./lib/Collections/contact_chat.js");
require("./lib/Collections/delete_alerte.js");
require("./lib/Collections/favoris.js");
require("./lib/Collections/friends.js");
require("./lib/Collections/histoire.js");
require("./lib/Collections/messages_signaler.js");
require("./lib/Collections/notifications.js");
require("./lib/Collections/posts.js");
require("./lib/Collections/rejoindre.js");
require("./lib/Collections/request.js");
require("./lib/Collections/user.js");
require("./lib/Collections/userBloquer_IP.js");
require("./lib/Collections/visites.js");
require("./lib/permission.js");
require("./lib/router.js");
require("./server/fixture.js");
require("./server/items.js");
require("./server/methodes.js");
require("./server/publication.js");
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
