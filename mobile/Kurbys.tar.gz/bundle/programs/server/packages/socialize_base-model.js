(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var ServerTime = Package['socialize:server-time'].ServerTime;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;

/* Package-scope variables */
var BaseModel;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/socialize_base-model/packages/socialize_base-model.js                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/socialize:base-model/base-model.js                                                        //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
//Object.create shim                                                                                  // 1
if (typeof Object.create != 'function') {                                                             // 2
    Object.create = (function() {                                                                     // 3
        var thing = function() {};                                                                    // 4
        return function (prototype) {                                                                 // 5
            if (arguments.length > 1) {                                                               // 6
                throw Error('Second argument not supported');                                         // 7
            }                                                                                         // 8
            if (typeof prototype != 'object') {                                                       // 9
                throw TypeError('Argument must be an object');                                        // 10
            }                                                                                         // 11
            thing.prototype = prototype;                                                              // 12
            var result = new thing();                                                                 // 13
            thing.prototype = null;                                                                   // 14
            return result;                                                                            // 15
        };                                                                                            // 16
    })();                                                                                             // 17
}                                                                                                     // 18
                                                                                                      // 19
/*globals BaseModel:true*/                                                                            // 20
                                                                                                      // 21
BaseModel = function(){};                                                                             // 22
                                                                                                      // 23
BaseModel.createEmpty = function (_id) {                                                              // 24
    return new this({_id:_id});                                                                       // 25
};                                                                                                    // 26
                                                                                                      // 27
BaseModel.extend = function() {                                                                       // 28
    var child = function(document) {                                                                  // 29
        _.extend(this, document);                                                                     // 30
    };                                                                                                // 31
    _.extend(child, this);                                                                            // 32
    child.prototype = Object.create(this.prototype);                                                  // 33
    child.prototype.constructor = child;                                                              // 34
    child.prototype._parent_ = this;                                                                  // 35
    child.prototype._super_ = this.prototype;                                                         // 36
                                                                                                      // 37
    return child;                                                                                     // 38
};                                                                                                    // 39
                                                                                                      // 40
BaseModel.extendAndSetupCollection = function(collectionName) {                                       // 41
    var model = this.extend();                                                                        // 42
                                                                                                      // 43
    model.collection = model.prototype._collection = new Mongo.Collection(collectionName, {           // 44
        transform: function(document){                                                                // 45
            return new model(document);                                                               // 46
        }                                                                                             // 47
    });                                                                                               // 48
                                                                                                      // 49
    Meteor[collectionName] = model.collection;                                                        // 50
                                                                                                      // 51
    return model;                                                                                     // 52
};                                                                                                    // 53
                                                                                                      // 54
BaseModel.appendSchema = function(schemaObject) {                                                     // 55
    var schema = new SimpleSchema(schemaObject);                                                      // 56
    var collection = this.prototype._collection;                                                      // 57
                                                                                                      // 58
    if(collection){                                                                                   // 59
        collection.attachSchema(schema);                                                              // 60
    }else{                                                                                            // 61
        throw new Error("Can't append schema to non existent collection. Either use extendAndSetupCollection() or assign a collection to Model.prototype._collection");
    }                                                                                                 // 63
};                                                                                                    // 64
                                                                                                      // 65
BaseModel.methods = function(methodMap) {                                                             // 66
    var self = this;                                                                                  // 67
    if(_.isObject(methodMap)){                                                                        // 68
        _.each(methodMap, function(method, name){                                                     // 69
            if(_.isFunction(method)){                                                                 // 70
                if(!self.prototype[name]){                                                            // 71
                    self.prototype[name] = method;                                                    // 72
                }else{                                                                                // 73
                    throw new Meteor.Error("existent-method", "The method "+name+" already exists."); // 74
                }                                                                                     // 75
            }                                                                                         // 76
        });                                                                                           // 77
    }                                                                                                 // 78
};                                                                                                    // 79
                                                                                                      // 80
BaseModel.prototype.getSchema = function() {                                                          // 81
    return this._collection._c2._simpleSchema;                                                        // 82
};                                                                                                    // 83
                                                                                                      // 84
BaseModel.prototype.checkCollectionExists = function() {                                              // 85
    if(!this._collection) {                                                                           // 86
        throw new Error("No collection found. Either use extendAndSetupCollection() or assign a collection to Model.prototype._collection");
    }                                                                                                 // 88
};                                                                                                    // 89
                                                                                                      // 90
BaseModel.prototype.checkOwnership = function() {                                                     // 91
    return this.userId === Meteor.userId();                                                           // 92
};                                                                                                    // 93
                                                                                                      // 94
BaseModel.prototype.save = function(callback) {                                                       // 95
    this.checkCollectionExists();                                                                     // 96
    var obj = {};                                                                                     // 97
    var schema = this.getSchema();                                                                    // 98
                                                                                                      // 99
    _.each(this, function(value, key) {                                                               // 100
        obj[key] = value;                                                                             // 101
    });                                                                                               // 102
                                                                                                      // 103
    if(Meteor.isClient && schema){                                                                    // 104
        obj = schema.clean(obj);                                                                      // 105
    }                                                                                                 // 106
                                                                                                      // 107
    if(this._id){                                                                                     // 108
        this._collection.update(this._id, {$set:obj}, callback);                                      // 109
    }else{                                                                                            // 110
        this._id = this._collection.insert(obj, callback);                                            // 111
    }                                                                                                 // 112
                                                                                                      // 113
    return this;                                                                                      // 114
};                                                                                                    // 115
                                                                                                      // 116
BaseModel.prototype.update = function(modifier) {                                                     // 117
    if(this._id){                                                                                     // 118
        this.checkCollectionExists();                                                                 // 119
                                                                                                      // 120
        this._collection.update(this._id, modifier);                                                  // 121
    }                                                                                                 // 122
};                                                                                                    // 123
                                                                                                      // 124
BaseModel.prototype.remove = function() {                                                             // 125
    if(this._id){                                                                                     // 126
        this.checkCollectionExists();                                                                 // 127
                                                                                                      // 128
        this._collection.remove({_id:this._id});                                                      // 129
    }                                                                                                 // 130
};                                                                                                    // 131
                                                                                                      // 132
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/socialize:base-model/security.js                                                          //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
SimpleSchema.messages({Untrusted: "Inserts/Updates from untrusted code not supported"});              // 1
                                                                                                      // 2
SimpleSchema.denyUntrusted = function() {                                                             // 3
    if(this.isSet){                                                                                   // 4
        var autoValue = this.definition.autoValue && this.definition.autoValue.call(this);            // 5
        var defaultValue = this.definition.defaultValue;                                              // 6
                                                                                                      // 7
        if(this.value != defaultValue && this.value != autoValue && !this.isFromTrustedCode){         // 8
            return "Untrusted";                                                                       // 9
        }                                                                                             // 10
    }                                                                                                 // 11
};                                                                                                    // 12
                                                                                                      // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['socialize:base-model'] = {}, {
  BaseModel: BaseModel
});

})();
