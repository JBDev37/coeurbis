(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var io;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/joncursi_socket-io-client/packages/joncursi_socket-io-client. //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/joncursi:socket-io-client/socket-io-client.js            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
io = Npm.require('socket.io-client');                                // 1
///////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['joncursi:socket-io-client'] = {}, {
  io: io
});

})();
