var require = meteorInstall({"lib":{"Collections":{"Chat.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/Chat.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Chat = new Mongo.Collection('chat');                                                                              // 1
Chat.allow({                                                                                                      // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    message: function (postAttributes) {                                                                          // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date(),                                                                                // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Chat.insert(post);                                                                           // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    },                                                                                                            // 20
    bloquer_user: function (postAttributes) {                                                                     // 23
        var post = _.extend(postAttributes, {                                                                     // 24
            date: new Date()                                                                                      // 25
        });                                                                                                       // 24
                                                                                                                  //
        var postId = UserBloquer.insert(post);                                                                    // 27
        return {                                                                                                  // 28
            _id: postId                                                                                           // 29
        };                                                                                                        // 28
    }                                                                                                             // 31
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"UserBloquer.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/UserBloquer.js                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer = new Mongo.Collection('userBloquer');                                                                // 1
UserBloquer.allow({                                                                                               // 3
  update: function (userId) {                                                                                     // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId) {                                                                                     // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/alerte.js                                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Alertes = new Mongo.Collection('alertes');                                                                        // 1
Alertes.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    alerteInsert: function (postAttributes) {                                                                     // 11
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            author_id: user._id,                                                                                  // 14
            author_name: user.username,                                                                           // 15
            gender: user.profile.gender,                                                                          // 16
            post_date: new Date()                                                                                 // 17
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 19
        return {                                                                                                  // 20
            _id: postId                                                                                           // 21
        };                                                                                                        // 20
    },                                                                                                            // 23
    alerteInsert1: function (postAttributes) {                                                                    // 25
        var user = Meteor.user();                                                                                 // 26
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 27
            author_id: user._id,                                                                                  // 28
            author_name: user.username,                                                                           // 29
            gender: user.profile.gender,                                                                          // 30
            post_date: new Date()                                                                                 // 31
        });                                                                                                       // 27
                                                                                                                  //
        var postId = Alertes.insert(post);                                                                        // 33
        return {                                                                                                  // 34
            _id: postId                                                                                           // 35
        };                                                                                                        // 34
    }                                                                                                             // 37
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"avertissement.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/avertissement.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Avertissement = new Mongo.Collection('avertissement_user');                                                       // 1
Avertissement.allow({                                                                                             // 3
  insert: function (userId, post) {                                                                               // 4
    return true;                                                                                                  // 4
  },                                                                                                              // 4
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comment.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/comment.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Comments = new Mongo.Collection('comments');                                                                      // 1
Meteor.methods({                                                                                                  // 4
  commentInsert: function (commentAttributes) {                                                                   // 5
    /*check(this.userId, String);                                                                                 // 6
    check(commentAttributes, {                                                                                    //
      postId: String,                                                                                             //
      body: String                                                                                                //
    });*/var user = Meteor.user();                                                                                //
    var post = Posts.findOne(commentAttributes.postId);                                                           // 12
    if (!post) throw new Meteor.Error('invalid-comment', 'Vous devez commenter sur un post');                     // 13
    comment = _.extend(commentAttributes, {                                                                       // 15
      userId: user._id,                                                                                           // 16
      gender: user.profile.gender,                                                                                // 17
      author: user.username,                                                                                      // 18
      submitted: new Date(),                                                                                      // 19
      upvoters: [],                                                                                               // 20
      votes: 0,                                                                                                   // 21
      nbr_votant: 0                                                                                               // 22
    }); // crée le commentaire et enregistre l'id                                                                 // 15
                                                                                                                  //
    comment._id = Comments.insert(comment); // crée maintenant une notification, informant l'utilisateur qu'il y a eu un commentaire
                                                                                                                  //
    createCommentNotification(comment);                                                                           // 27
    return comment._id;                                                                                           // 28
  },                                                                                                              // 29
  upvote: function (commentId) {                                                                                  // 31
    check(this.userId, String);                                                                                   // 32
    check(commentId, String);                                                                                     // 33
    var comment = Comments.findOne(commentId);                                                                    // 34
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 35
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 39
      $addToSet: {                                                                                                // 40
        upvoters: this.userId                                                                                     // 40
      },                                                                                                          // 40
      $inc: {                                                                                                     // 41
        votes: 1                                                                                                  // 41
      }                                                                                                           // 41
    });                                                                                                           // 39
    Comments.update(comment._id, {                                                                                // 43
      $inc: {                                                                                                     // 44
        nbr_votant: 1                                                                                             // 44
      }                                                                                                           // 44
    });                                                                                                           // 43
  },                                                                                                              // 46
  downvote: function (commentId) {                                                                                // 48
    check(this.userId, String);                                                                                   // 49
    check(commentId, String);                                                                                     // 50
    var comment = Comments.findOne(commentId);                                                                    // 51
    if (!comment) throw new Meteor.Error('invalid', 'Post not found');                                            // 52
    if (_.include(comment.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');
    Comments.update(comment._id, {                                                                                // 56
      $addToSet: {                                                                                                // 57
        upvoters: this.userId                                                                                     // 57
      },                                                                                                          // 57
      $inc: {                                                                                                     // 58
        votes: -1                                                                                                 // 58
      }                                                                                                           // 58
    });                                                                                                           // 56
    Comments.update(comment._id, {                                                                                // 60
      $inc: {                                                                                                     // 61
        nbr_votant: 1                                                                                             // 61
      }                                                                                                           // 61
    });                                                                                                           // 60
  }                                                                                                               // 63
});                                                                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentaires.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/commentaires.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Commentaires = new Mongo.Collection('commentaires');                                                              // 1
Commentaires.allow({                                                                                              // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    AddComment: function (postAttributes) {                                                                       // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            date: new Date(),                                                                                     // 12
            read: false                                                                                           // 13
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Commentaires.insert(post);                                                                   // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"conseilleres.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/conseilleres.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Conseilleres = new Mongo.Collection('conseilleres');                                                              // 1
Conseilleres.allow({                                                                                              // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  AddConseillere: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      user_id: user._id,                                                                                          // 13
      username: user.username,                                                                                    // 14
      gender: user.profile.gender,                                                                                // 15
      date: new Date(),                                                                                           // 16
      lastLogin: new Date()                                                                                       // 17
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Conseilleres.insert(post);                                                                       // 19
    return {                                                                                                      // 20
      _id: postId                                                                                                 // 21
    };                                                                                                            // 20
  }                                                                                                               // 23
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"contact_chat.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/contact_chat.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var _objectDestructuringEmpty2 = require("babel-runtime/helpers/objectDestructuringEmpty");                       //
                                                                                                                  //
var _objectDestructuringEmpty3 = _interopRequireDefault(_objectDestructuringEmpty2);                              //
                                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                 //
                                                                                                                  //
ContactChat = new Mongo.Collection('contact_Chat');                                                               // 1
ContactChat.allow({                                                                                               // 3
  update: function () {                                                                                           // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (_ref) {                                                                                       // 6
    (0, _objectDestructuringEmpty3.default)(_ref);                                                                // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  contact_chat: function (postAttributes) {                                                                       // 10
    var post = _.extend(postAttributes, {                                                                         // 11
      date: new Date(),                                                                                           // 12
      last_message: ' ',                                                                                          // 13
      read: false                                                                                                 // 14
    });                                                                                                           // 11
                                                                                                                  //
    var postId = ContactChat.insert(post);                                                                        // 16
    return {                                                                                                      // 17
      _id: postId                                                                                                 // 18
    };                                                                                                            // 17
  }                                                                                                               // 20
});                                                                                                               // 9
Meteor.methods({                                                                                                  // 25
  update_active: function (postAttributes) {                                                                      // 26
    var userId = Meteor.userId();                                                                                 // 27
                                                                                                                  //
    if (postAttributes.id_from_active) {                                                                          // 28
      ContactChat.update({                                                                                        // 29
        from_id: userId                                                                                           // 29
      }, {                                                                                                        // 29
        $set: {                                                                                                   // 29
          "id_from_active": false                                                                                 // 29
        }                                                                                                         // 29
      }, {                                                                                                        // 29
        multi: true                                                                                               // 29
      });                                                                                                         // 29
      ContactChat.update({                                                                                        // 30
        _id: postAttributes._id                                                                                   // 30
      }, {                                                                                                        // 30
        $set: {                                                                                                   // 30
          "id_from_active": true                                                                                  // 30
        }                                                                                                         // 30
      });                                                                                                         // 30
    }                                                                                                             // 30
                                                                                                                  //
    if (postAttributes.id_to_active) {                                                                            // 32
      ContactChat.update({                                                                                        // 33
        to_id: userId                                                                                             // 33
      }, {                                                                                                        // 33
        $set: {                                                                                                   // 33
          "id_to_active": false                                                                                   // 33
        }                                                                                                         // 33
      }, {                                                                                                        // 33
        multi: true                                                                                               // 33
      });                                                                                                         // 33
      ContactChat.update({                                                                                        // 34
        _id: postAttributes._id                                                                                   // 34
      }, {                                                                                                        // 34
        $set: {                                                                                                   // 34
          "id_to_active": true                                                                                    // 34
        }                                                                                                         // 34
      });                                                                                                         // 34
    } //ContactChat.update({from_id : userId}, {$set:{ "active" : false }} );                                     // 34
    //ContactChat.update({to_id : userId}, {$set:{ "active" : false }} );                                         // 36
                                                                                                                  //
                                                                                                                  //
    ContactChat.update({                                                                                          // 37
      _id: postAttributes._id                                                                                     // 37
    }, {                                                                                                          // 37
      $set: {                                                                                                     // 37
        "active": true                                                                                            // 37
      }                                                                                                           // 37
    });                                                                                                           // 37
  }                                                                                                               // 38
});                                                                                                               // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"delete_alerte.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/delete_alerte.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
DeleteAlertes = new Mongo.Collection('delete_alertes');                                                           // 1
DeleteAlertes.allow({                                                                                             // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    delete_alerte: function (postAttributes) {                                                                    // 10
        var post = _.extend(postAttributes, {});                                                                  // 11
                                                                                                                  //
        var postId = DeleteAlertes.insert(post);                                                                  // 14
        return {                                                                                                  // 15
            _id: postId                                                                                           // 16
        };                                                                                                        // 15
    }                                                                                                             // 18
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"friends.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/friends.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Friends = new Mongo.Collection('friends');                                                                        // 1
Friends.allow({                                                                                                   // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    ami_accepte: function (postAttributes) {                                                                      // 10
        /*check(Meteor.userId(), String);                                                                         // 11
        check(postAttributes, {                                                                                   //
            post_title: String,                                                                                   //
            post_content: String,                                                                                 //
            categorie: String                                                                                     //
        });*/var user = Meteor.user();                                                                            //
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 18
            date: new Date()                                                                                      // 19
        });                                                                                                       // 18
                                                                                                                  //
        var postId = Friends.insert(post);                                                                        // 22
        return {                                                                                                  // 23
            _id: postId                                                                                           // 24
        };                                                                                                        // 23
    }                                                                                                             // 26
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"histoire.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/histoire.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Histoires = new Mongo.Collection('histoires');                                                                    // 1
Histoires.allow({                                                                                                 // 3
  update: function (userId, post) {                                                                               // 5
    return true;                                                                                                  // 5
  },                                                                                                              // 5
  remove: function (userId, post) {                                                                               // 6
    return true;                                                                                                  // 6
  }                                                                                                               // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
  histoireInsert: function (postAttributes) {                                                                     // 10
    var user = Meteor.user();                                                                                     // 11
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 12
      post_author: user._id,                                                                                      // 13
      author_name: user.username,                                                                                 // 14
      gender: user.profile.gender,                                                                                // 15
      post_date: new Date()                                                                                       // 16
    });                                                                                                           // 12
                                                                                                                  //
    var postId = Histoires.insert(post);                                                                          // 18
    return {                                                                                                      // 19
      _id: postId                                                                                                 // 20
    };                                                                                                            // 19
  }                                                                                                               // 22
}); /*validatePost = function (post) {                                                                            // 9
      var errors = {};                                                                                            //
      if (!post.post_title)                                                                                       //
        errors.title = "Please fill in a headline";                                                               //
      if (!post.content)                                                                                          //
        errors.url = "Please fill in a URL";                                                                      //
      return errors;                                                                                              //
    }*/                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages_signaler.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/messages_signaler.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Signaler = new Mongo.Collection('messages_signaler');                                                             // 1
Signaler.allow({                                                                                                  // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    signaler_message: function (postAttributes) {                                                                 // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = Signaler.insert(post);                                                                       // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/notifications.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Notifications = new Mongo.Collection('notifications');                                                            // 1
Notifications.allow({                                                                                             // 3
  update: function (userId, doc, fieldNames) {                                                                    // 4
    return ownsDocument(userId, doc) && fieldNames.length === 1 && fieldNames[0] === 'read';                      // 5
  }                                                                                                               // 7
});                                                                                                               // 3
                                                                                                                  //
createCommentNotification = function (comment) {                                                                  // 10
  var post = Posts.findOne(comment.postId);                                                                       // 11
                                                                                                                  //
  if (comment.userId !== post.post_author) {                                                                      // 12
    Notifications.insert({                                                                                        // 13
      userId: post.post_author,                                                                                   // 14
      postId: post._id,                                                                                           // 15
      commentId: comment._id,                                                                                     // 16
      commenterName: comment.author,                                                                              // 17
      read: false                                                                                                 // 18
    });                                                                                                           // 13
  }                                                                                                               // 20
};                                                                                                                // 21
                                                                                                                  //
createFriendsNotification = function (post) {                                                                     // 23
  Notifications.insert({                                                                                          // 24
    from_id: post.from_id,                                                                                        // 25
    to_id: post.to_id,                                                                                            // 26
    name_from_id: post.name_from_id,                                                                              // 27
    name_to_id: post.name_to_id,                                                                                  // 28
    date: post.date,                                                                                              // 29
    read: false                                                                                                   // 30
  });                                                                                                             // 24
};                                                                                                                // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"posts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/posts.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Posts = new Mongo.Collection('posts'); /*Posts.allow({                                                            // 1
                                         insert: function(userId, doc) {                                          //
                                           // autoriser les posts seulement si l'utilisateur est authentifié      //
                                           return !! userId;                                                      //
                                         }                                                                        //
                                        });*/                                                                     //
Posts.allow({                                                                                                     // 10
  update: function (userId, post) {                                                                               // 12
    return ownsDocument(userId, post);                                                                            // 12
  },                                                                                                              // 12
  remove: function (userId, post) {                                                                               // 13
    return ownsDocument(userId, post);                                                                            // 13
  }                                                                                                               // 13
});                                                                                                               // 10
Meteor.users.allow({                                                                                              // 16
  update: function (userId, post) {                                                                               // 17
    return true;                                                                                                  // 17
  }                                                                                                               // 17
}); /*var errors = validatePost(postAttributes);                                                                  // 16
        if (errors.post_title || errors.post_content)                                                             //
          throw new Meteor.Error('invalid-post', "You must set a title and URL for your post");*/                 //
Meteor.methods({                                                                                                  // 24
  postInsert: function (postAttributes) {                                                                         // 25
    /*check(Meteor.userId(), String);                                                                             // 26
    check(postAttributes, {                                                                                       //
        post_title: String,                                                                                       //
        post_content: String,                                                                                     //
        categorie: String                                                                                         //
    });*/var user = Meteor.user();                                                                                //
                                                                                                                  //
    var post = _.extend(postAttributes, {                                                                         // 33
      post_author: user._id,                                                                                      // 34
      author_name: user.username,                                                                                 // 35
      gender: user.profile.gender,                                                                                // 36
      post_date: new Date(),                                                                                      // 37
      upvoters: [],                                                                                               // 38
      votes: 0                                                                                                    // 39
    });                                                                                                           // 33
                                                                                                                  //
    var postId = Posts.insert(post);                                                                              // 41
    return {                                                                                                      // 42
      _id: postId                                                                                                 // 43
    };                                                                                                            // 42
  },                                                                                                              // 45
  upvote1: function (postId) {                                                                                    // 47
    check(this.userId, String);                                                                                   // 48
    check(postId, String);                                                                                        // 49
    var post = Posts.findOne(postId);                                                                             // 50
    if (!post) throw new Meteor.Error('invalid', 'Post not found');                                               // 51
    if (_.include(post.upvoters, this.userId)) throw new Meteor.Error('invalid', 'Already upvoted this post');    // 53
    Posts.update(post._id, {                                                                                      // 55
      $addToSet: {                                                                                                // 56
        upvoters: this.userId                                                                                     // 56
      },                                                                                                          // 56
      $inc: {                                                                                                     // 57
        votes: -1                                                                                                 // 57
      }                                                                                                           // 57
    });                                                                                                           // 55
  }                                                                                                               // 59
});                                                                                                               // 24
                                                                                                                  //
validatePost = function (post) {                                                                                  // 63
  var errors = {};                                                                                                // 64
  if (!post.post_title) errors.title = "Please fill in a headline";                                               // 65
  if (!post.content) errors.url = "Please fill in a URL";                                                         // 67
  return errors;                                                                                                  // 69
};                                                                                                                // 70
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/request.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Requests = new Mongo.Collection('requests');                                                                      // 1
Requests.allow({                                                                                                  // 3
    update: function () {                                                                                         // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function () {                                                                                         // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    demande_ami: function (postAttributes) {                                                                      // 10
        var user = Meteor.user();                                                                                 // 12
                                                                                                                  //
        var post = _.extend(postAttributes, {                                                                     // 13
            date: new Date()                                                                                      // 14
        });                                                                                                       // 13
                                                                                                                  //
        var postId = Requests.insert(post);                                                                       // 16
        createFriendsNotification(post);                                                                          // 17
        return {                                                                                                  // 18
            _id: postId                                                                                           // 19
        };                                                                                                        // 18
    },                                                                                                            // 21
    delete_request: function (postAttributes) {                                                                   // 23
        var user = Meteor.userId();                                                                               // 24
                                                                                                                  //
        var post = _.extend(postAttributes, {});                                                                  // 25
                                                                                                                  //
        Requests.remove({                                                                                         // 29
            "from_id": post.from_id,                                                                              // 29
            "to_id": user                                                                                         // 29
        });                                                                                                       // 29
        Requests.remove({                                                                                         // 30
            "from_id": user,                                                                                      // 30
            "to_id": post.from_id                                                                                 // 30
        });                                                                                                       // 30
    }                                                                                                             // 31
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/user.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Mongo = void 0;                                                                                               // 1
module.watch(require("meteor/mongo"), {                                                                           // 1
  Mongo: function (v) {                                                                                           // 1
    Mongo = v;                                                                                                    // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
Meteor.users.allow({                                                                                              // 2
  /*update: function(userId, post) { return ownsDocument(userId, post); },*/remove: function (userId) {           // 4
    return true;                                                                                                  // 5
  }                                                                                                               // 5
});                                                                                                               // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userBloquer_IP.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/userBloquer_IP.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
UserBloquer_IP = new Mongo.Collection('user_bloquer_IP');                                                         // 1
UserBloquer_IP.allow({                                                                                            // 3
    update: function (userId, post) {                                                                             // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId, post) {                                                                             // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 10
    bloquerUser_IP: function (postAttributes) {                                                                   // 11
        var post = _.extend(postAttributes, {                                                                     // 12
            date: new Date()                                                                                      // 13
        });                                                                                                       // 12
                                                                                                                  //
        var postId = UserBloquer_IP.insert(post);                                                                 // 15
        return {                                                                                                  // 16
            _id: postId                                                                                           // 17
        };                                                                                                        // 16
    }                                                                                                             // 19
});                                                                                                               // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"visites.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/Collections/visites.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Visites = new Mongo.Collection('visites');                                                                        // 1
Visites.allow({                                                                                                   // 3
    update: function (userId) {                                                                                   // 5
        return true;                                                                                              // 5
    },                                                                                                            // 5
    remove: function (userId) {                                                                                   // 6
        return true;                                                                                              // 6
    }                                                                                                             // 6
});                                                                                                               // 3
Meteor.methods({                                                                                                  // 9
    add_visites: function (postAttributes) {                                                                      // 10
        var post = _.extend(postAttributes, {                                                                     // 11
            post_date: new Date()                                                                                 // 12
        });                                                                                                       // 11
                                                                                                                  //
        var postId = Visites.insert(post);                                                                        // 15
        return {                                                                                                  // 17
            _id: postId                                                                                           // 18
        };                                                                                                        // 17
    }                                                                                                             // 20
});                                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"permission.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/permission.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// check that the userId specified owns the documents                                                             // 1
ownsDocument = function (userId, doc) {                                                                           // 2
  //return doc && doc.userId === userId;                                                                          // 3
  return 1 === 1;                                                                                                 // 4
};                                                                                                                // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/router.js                                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Router.configure({                                                                                                // 1
  layoutTemplate: 'layout',                                                                                       // 2
  loadingTemplate: 'loading',                                                                                     // 3
  notFoundTemplate: 'notFound',                                                                                   // 4
  waitOn: function () {                                                                                           // 5
    return [Meteor.subscribe('notifications'), Meteor.subscribe('posts'), Meteor.subscribe('comments'), Meteor.subscribe('histoires'), Meteor.subscribe('requests'), Meteor.subscribe('friends'), Meteor.subscribe('chat'), Meteor.subscribe('userBloquer'), Meteor.subscribe('contact_Chat'), Meteor.subscribe('userStatus'), Meteor.subscribe('userIP'), Meteor.subscribe('visites'), Meteor.subscribe('commentaires'), Meteor.subscribe('messages_signaler'), Meteor.subscribe('avertissement_user'), Meteor.subscribe('user_bloquer_IP'), Meteor.subscribe('alertes'), Meteor.subscribe('delete_alertes'), Meteor.subscribe('conseilleres'), Meteor.subscribe('lastlogin'), Meteor.subscribe('password')];
  }                                                                                                               // 29
});                                                                                                               // 1
Router.route('/', {                                                                                               // 35
  name: 'index',                                                                                                  // 36
  template: 'postsList'                                                                                           // 37
});                                                                                                               // 35
Router.route('/posts/:_id', {                                                                                     // 42
  name: 'postPage',                                                                                               // 43
  template: 'postPage',                                                                                           // 44
  data: function () {                                                                                             // 45
    return Posts.findOne(this.params._id);                                                                        // 46
  }                                                                                                               // 46
});                                                                                                               // 42
Router.route('/posts_mobile/:_id', {                                                                              // 49
  name: 'postPage_mobile',                                                                                        // 50
  template: 'postPage_mobile',                                                                                    // 51
  data: function () {                                                                                             // 52
    return Posts.findOne(this.params._id);                                                                        // 53
  }                                                                                                               // 53
});                                                                                                               // 49
Router.route('/posts/:_id/edit', {                                                                                // 57
  name: 'postEdit',                                                                                               // 58
  data: function () {                                                                                             // 59
    return Posts.findOne(this.params._id);                                                                        // 60
  }                                                                                                               // 60
});                                                                                                               // 57
Router.route('/contact', {                                                                                        // 63
  name: 'contact',                                                                                                // 64
  template: 'contact'                                                                                             // 65
});                                                                                                               // 63
Router.route('/profil/:post_author?', {                                                                           // 69
  name: 'profil',                                                                                                 // 70
  template: 'profil',                                                                                             // 71
  data: function () {                                                                                             // 72
    return Meteor.users.findOne(this.params.post_author);                                                         // 73
  }                                                                                                               // 73
});                                                                                                               // 69
Router.route('/profil/:_id', {                                                                                    // 76
  name: 'mon_profil',                                                                                             // 77
  template: 'profil'                                                                                              // 78
});                                                                                                               // 76
Router.route('/messagerie/:post_author?', {                                                                       // 82
  name: 'messagerie',                                                                                             // 83
  template: 'messagerie',                                                                                         // 84
  data: function () {                                                                                             // 85
    return Meteor.users.findOne(this.params.post_author);                                                         // 86
  }                                                                                                               // 88
});                                                                                                               // 82
Router.route('/messagerie_vierge/:post_author?', {                                                                // 91
  name: 'messagerie_vierge',                                                                                      // 92
  template: 'messagerie_vierge',                                                                                  // 93
  data: function () {                                                                                             // 94
    return Meteor.users.findOne(this.params.post_author);                                                         // 95
  }                                                                                                               // 97
});                                                                                                               // 91
Router.route('/messagerie_mobile/:post_author?', {                                                                // 100
  name: 'messagerie_mobile',                                                                                      // 101
  template: 'messagerie_mobile',                                                                                  // 102
  data: function () {                                                                                             // 105
    return Meteor.users.findOne(this.params.post_author);                                                         // 106
  }                                                                                                               // 108
});                                                                                                               // 100
Router.route('/mot_de_passe', {                                                                                   // 111
  name: 'mot_de_passe',                                                                                           // 112
  template: 'mot_de_passe'                                                                                        // 113
});                                                                                                               // 111
Router.route('/signaler_bug', {                                                                                   // 117
  name: 'signaler_bug',                                                                                           // 118
  template: 'signaler_bug'                                                                                        // 119
});                                                                                                               // 117
Router.route('/ameliore_site', {                                                                                  // 123
  name: 'ameliore_site',                                                                                          // 124
  template: 'ameliore_site'                                                                                       // 125
});                                                                                                               // 123
Router.route('/supprimer_compte', {                                                                               // 129
  name: 'supprimer_compte',                                                                                       // 130
  template: 'supprimer_compte'                                                                                    // 131
});                                                                                                               // 129
Router.route('/inscription', {                                                                                    // 135
  name: 'inscription',                                                                                            // 136
  template: 'inscription'                                                                                         // 137
});                                                                                                               // 135
Router.route('/devenir_conseillere', {                                                                            // 141
  name: 'devenir_conseillere',                                                                                    // 142
  template: 'devenir_conseillere'                                                                                 // 143
});                                                                                                               // 141
Router.route('/devenir_conseillere_mobile', {                                                                     // 147
  name: 'devenir_conseillere_mobile',                                                                             // 148
  template: 'devenir_conseillere_mobile'                                                                          // 149
});                                                                                                               // 147
Router.route('/confirmation_conseillere', {                                                                       // 153
  name: 'confirmation_conseillere',                                                                               // 154
  template: 'confirmation_conseillere'                                                                            // 155
});                                                                                                               // 153
Router.route('/confirmation_conseillere_mobile', {                                                                // 158
  name: 'confirmation_conseillere_mobile',                                                                        // 159
  template: 'confirmation_conseillere_mobile'                                                                     // 160
});                                                                                                               // 158
Router.route('/recherche_conseillere', {                                                                          // 163
  name: 'recherche_conseillere',                                                                                  // 164
  template: 'recherche_conseillere'                                                                               // 165
});                                                                                                               // 163
Router.route('/recherche_mobile', {                                                                               // 169
  name: 'recherche_mobile',                                                                                       // 170
  template: 'recherche_mobile'                                                                                    // 171
});                                                                                                               // 169
Router.route('/resultat_conseillere/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere',                                                                                   // 176
  template: 'resultat_conseillere',                                                                               // 177
  data: function () {                                                                                             // 178
    return Conseilleres.find();                                                                                   // 179
  }                                                                                                               // 180
});                                                                                                               // 175
Router.route('/resultat_conseillere_mobile/:gender?/:college?/:lycee?/:adulte?/:amour?/:amitie?/:confiance?/:sexo?/:autre?/:les_deux?', {
  name: 'resultat_conseillere_mobile',                                                                            // 185
  template: 'resultat_conseillere_mobile',                                                                        // 186
  data: function () {                                                                                             // 187
    return Conseilleres.find();                                                                                   // 188
  }                                                                                                               // 189
});                                                                                                               // 184
Router.route('/classement-conseilleres', {                                                                        // 193
  name: 'classementComplet',                                                                                      // 194
  template: 'classementComplet'                                                                                   // 195
});                                                                                                               // 193
Router.route('/classement-conseilleres-mobile', {                                                                 // 199
  name: 'classementComplet_mobile',                                                                               // 200
  template: 'classementComplet_mobile'                                                                            // 201
});                                                                                                               // 199
Router.route('/conseiller/:post_author?', {                                                                       // 206
  name: 'presentation_conseiller',                                                                                // 207
  template: 'presentation_conseiller',                                                                            // 208
  data: function () {                                                                                             // 209
    return Meteor.users.findOne(this.params.post_author);                                                         // 210
  }                                                                                                               // 210
});                                                                                                               // 206
Router.route('/presentation_conseiller_mobile/:post_author?', {                                                   // 213
  name: 'presentation_conseiller_mobile',                                                                         // 214
  template: 'presentation_conseiller_mobile',                                                                     // 215
  data: function () {                                                                                             // 216
    return Meteor.users.findOne(this.params.post_author);                                                         // 217
  }                                                                                                               // 217
});                                                                                                               // 213
Router.route('/histoire/:post_author?', {                                                                         // 222
  name: 'histoire',                                                                                               // 223
  template: 'histoire',                                                                                           // 224
  data: function () {                                                                                             // 225
    return Meteor.users.findOne(this.params.post_author);                                                         // 226
  }                                                                                                               // 226
});                                                                                                               // 222
Router.route('/histoire_mobile/:post_author?', {                                                                  // 229
  name: 'histoire_mobile',                                                                                        // 230
  template: 'histoire_mobile',                                                                                    // 231
  data: function () {                                                                                             // 232
    return Meteor.users.findOne(this.params.post_author);                                                         // 233
  }                                                                                                               // 233
});                                                                                                               // 229
Router.route('/amis/:post_author?', {                                                                             // 236
  name: 'amis',                                                                                                   // 237
  template: 'amis',                                                                                               // 238
  data: function () {                                                                                             // 239
    return Meteor.users.findOne(this.params.post_author);                                                         // 240
  }                                                                                                               // 240
});                                                                                                               // 236
Router.route('/visites/:post_author?', {                                                                          // 243
  name: 'visites',                                                                                                // 244
  template: 'visites',                                                                                            // 245
  data: function () {                                                                                             // 246
    return Meteor.users.findOne(this.params.post_author);                                                         // 247
  }                                                                                                               // 247
});                                                                                                               // 243
Router.route('/visites_mobile/:post_author?', {                                                                   // 250
  name: 'visites_mobile',                                                                                         // 251
  template: 'visites_mobile',                                                                                     // 252
  data: function () {                                                                                             // 253
    return Meteor.users.findOne(this.params.post_author);                                                         // 254
  }                                                                                                               // 254
});                                                                                                               // 250
Router.route('/personne_aide/:post_author?', {                                                                    // 257
  name: 'personne_aide',                                                                                          // 258
  template: 'personne_aide',                                                                                      // 259
  data: function () {                                                                                             // 260
    return Meteor.users.findOne(this.params.post_author);                                                         // 261
  }                                                                                                               // 261
});                                                                                                               // 257
Router.route('/personne_aide_mobile/:post_author?', {                                                             // 264
  name: 'personne_aide_mobile',                                                                                   // 265
  template: 'personne_aide_mobile',                                                                               // 266
  data: function () {                                                                                             // 267
    return Meteor.users.findOne(this.params.post_author);                                                         // 268
  }                                                                                                               // 268
});                                                                                                               // 264
Router.route('/messages_poste/:post_author?', {                                                                   // 271
  name: 'messages_poste',                                                                                         // 272
  template: 'messages_poste',                                                                                     // 273
  data: function () {                                                                                             // 274
    return Meteor.users.findOne(this.params.post_author);                                                         // 275
  }                                                                                                               // 275
});                                                                                                               // 271
Router.route('/messages_poste_mobile/:post_author?', {                                                            // 278
  name: 'messages_poste_mobile',                                                                                  // 279
  template: 'messages_poste_mobile',                                                                              // 280
  data: function () {                                                                                             // 281
    return Meteor.users.findOne(this.params.post_author);                                                         // 282
  }                                                                                                               // 282
});                                                                                                               // 278
Router.route('/commentaires/:post_author?', {                                                                     // 285
  name: 'commentaires',                                                                                           // 286
  template: 'commentaires',                                                                                       // 287
  data: function () {                                                                                             // 288
    return Meteor.users.findOne(this.params.post_author);                                                         // 289
  }                                                                                                               // 289
});                                                                                                               // 285
Router.route('/commentaires_mobile/:post_author?', {                                                              // 292
  name: 'commentaires_mobile',                                                                                    // 293
  template: 'commentaires_mobile',                                                                                // 294
  data: function () {                                                                                             // 295
    return Meteor.users.findOne(this.params.post_author);                                                         // 296
  }                                                                                                               // 296
});                                                                                                               // 292
Router.route('/rediger_commentaires_mobile/:post_author?', {                                                      // 299
  name: 'rediger_commentaires_mobile',                                                                            // 300
  template: 'rediger_commentaires_mobile',                                                                        // 301
  data: function () {                                                                                             // 302
    return Meteor.users.findOne(this.params.post_author);                                                         // 303
  }                                                                                                               // 303
});                                                                                                               // 299
Router.route('/ils_ont_aide/:post_author?', {                                                                     // 306
  name: 'ils_ont_aide',                                                                                           // 307
  template: 'ils_ont_aide',                                                                                       // 308
  data: function () {                                                                                             // 309
    return Meteor.users.findOne(this.params.post_author);                                                         // 310
  }                                                                                                               // 310
});                                                                                                               // 306
Router.route('/ils_ont_aide_mobile/:post_author?', {                                                              // 313
  name: 'ils_ont_aide_mobile',                                                                                    // 314
  template: 'ils_ont_aide_mobile',                                                                                // 315
  data: function () {                                                                                             // 316
    return Meteor.users.findOne(this.params.post_author);                                                         // 317
  }                                                                                                               // 317
});                                                                                                               // 313
Router.route('/alerte/:post_author?', {                                                                           // 320
  name: 'alerte',                                                                                                 // 321
  template: 'alerte',                                                                                             // 322
  data: function () {                                                                                             // 323
    return Meteor.users.findOne(this.params.post_author);                                                         // 324
  }                                                                                                               // 324
});                                                                                                               // 320
Router.route('/avertissement/:post_author?', {                                                                    // 327
  name: 'avertissement',                                                                                          // 328
  template: 'avertissement',                                                                                      // 329
  data: function () {                                                                                             // 330
    return Meteor.users.findOne(this.params.post_author);                                                         // 331
  }                                                                                                               // 331
});                                                                                                               // 327
Router.route('/avertissement_mobile/:post_author?', {                                                             // 334
  name: 'avertissement_mobile',                                                                                   // 335
  template: 'avertissement_mobile',                                                                               // 336
  data: function () {                                                                                             // 337
    return Meteor.users.findOne(this.params.post_author);                                                         // 338
  }                                                                                                               // 338
});                                                                                                               // 334
Router.route('/add_commentaire_mobile/:post_author?', {                                                           // 341
  name: 'add_commentaire_mobile',                                                                                 // 342
  template: 'add_commentaire_mobile',                                                                             // 343
  data: function () {                                                                                             // 344
    return Meteor.users.findOne(this.params.post_author);                                                         // 345
  }                                                                                                               // 345
});                                                                                                               // 341
Router.route('/valider_commentaire_mobile/:post_author?', {                                                       // 348
  name: 'valider_commentaire_mobile',                                                                             // 349
  template: 'valider_commentaire_mobile',                                                                         // 350
  data: function () {                                                                                             // 351
    return Meteor.users.findOne(this.params.post_author);                                                         // 352
  }                                                                                                               // 352
});                                                                                                               // 348
Router.route('/presentation/:post_author?', {                                                                     // 355
  name: 'presentation',                                                                                           // 356
  template: 'presentation',                                                                                       // 357
  data: function () {                                                                                             // 358
    return Meteor.users.findOne(this.params.post_author);                                                         // 359
  }                                                                                                               // 359
});                                                                                                               // 355
Router.route('/alertes_mobile/:post_author?', {                                                                   // 362
  name: 'alertes_mobile',                                                                                         // 363
  template: 'alertes_mobile',                                                                                     // 364
  data: function () {                                                                                             // 365
    return Meteor.users.findOne(this.params.post_author);                                                         // 366
  }                                                                                                               // 366
});                                                                                                               // 362
Router.route('/creerAlerte/:post_author?', {                                                                      // 369
  name: 'creerAlerte',                                                                                            // 370
  template: 'creerAlerte',                                                                                        // 371
  data: function () {                                                                                             // 372
    return Meteor.users.findOne(this.params.post_author);                                                         // 373
  }                                                                                                               // 373
});                                                                                                               // 369
Router.route('/valider_Alerte/:post_author?', {                                                                   // 376
  name: 'valider_Alerte',                                                                                         // 377
  template: 'valider_Alerte',                                                                                     // 378
  data: function () {                                                                                             // 379
    return Meteor.users.findOne(this.params.post_author);                                                         // 380
  }                                                                                                               // 380
});                                                                                                               // 376
Router.route('/presentation_mobile/:post_author?', {                                                              // 383
  name: 'presentation_mobile',                                                                                    // 384
  template: 'presentation_mobile',                                                                                // 385
  data: function () {                                                                                             // 386
    return Meteor.users.findOne(this.params.post_author);                                                         // 387
  }                                                                                                               // 387
});                                                                                                               // 383
Router.route('/notifications_mobile', {                                                                           // 390
  name: 'notifications_mobile',                                                                                   // 391
  template: 'notifications_mobile1'                                                                               // 392
});                                                                                                               // 390
Router.route('/profil_mobile/:post_author?', {                                                                    // 396
  name: 'profil_mobile',                                                                                          // 397
  template: 'profil_mobile',                                                                                      // 398
  data: function () {                                                                                             // 399
    return Meteor.users.findOne(this.params.post_author);                                                         // 400
  }                                                                                                               // 400
});                                                                                                               // 396
Router.route('/amis_mobile/:post_author?', {                                                                      // 403
  name: 'amis_mobile',                                                                                            // 404
  template: 'amis_mobile',                                                                                        // 405
  data: function () {                                                                                             // 406
    return Meteor.users.findOne(this.params.post_author);                                                         // 407
  }                                                                                                               // 407
});                                                                                                               // 403
Router.route('/connexion_mobile', {                                                                               // 410
  name: 'connexion_mobile',                                                                                       // 411
  template: 'connexion_mobile'                                                                                    // 412
});                                                                                                               // 410
Router.route('/supprimer_mon_compte', {                                                                           // 415
  name: 'supprimer_mon_compte',                                                                                   // 416
  template: 'supprimer_mon_compte'                                                                                // 417
});                                                                                                               // 415
Router.route('/dashboard', {                                                                                      // 420
  name: 'dashboard',                                                                                              // 421
  template: 'dashboard'                                                                                           // 422
});                                                                                                               // 420
Router.route('/dons', {                                                                                           // 425
  name: 'dons',                                                                                                   // 426
  template: 'dons'                                                                                                // 427
});                                                                                                               // 425
Router.route('/cgu', {                                                                                            // 430
  name: 'cgu',                                                                                                    // 431
  template: 'cgu'                                                                                                 // 432
});                                                                                                               // 430
Router.onBeforeAction('dataNotFound', {                                                                           // 438
  only: 'postPage'                                                                                                // 438
});                                                                                                               // 438
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixture.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/fixture.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
  Meteor: function (v) {                                                                                          // 1
    Meteor = v;                                                                                                   // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
module.watch(require("meteor/houston:admin"));                                                                    // 1
Houston.add_collection(Meteor.users);                                                                             // 6
Houston.add_collection(Houston._admins); /*var now = new Date().getTime();                                        // 7
                                           // crée deux utilisateurs                                              //
                                          var tomId = Meteor.users.insert({                                       //
                                            profile: { name: 'Tom Coleman' }                                      //
                                          });                                                                     //
                                          var tom = Meteor.users.findOne(tomId);                                  //
                                          var sachaId = Meteor.users.insert({                                     //
                                            profile: { name: 'Sacha Greif' }                                      //
                                          });                                                                     //
                                          var sacha = Meteor.users.findOne(sachaId);                              //
                                           var telescopeId = Posts.insert({                                       //
                                            post_title: 'Introducing Telescope',                                  //
                                            post_author: sacha._id,                                               //
                                            author_name: sacha.profile.name,                                      //
                                            //url: 'http://sachagreif.com/introducing-telescope/',                //
                                            post_date: new Date(now - 7 * 3600 * 1000)                            //
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: tom._id,                                                      //
                                            author: tom.profile.name,                                             //
                                            submitted: new Date(now - 5 * 3600 * 1000),                           //
                                            body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                          });                                                                     //
                                           Comments.insert({                                                      //
                                            postId: telescopeId,                                                  //
                                            userId: sacha._id,                                                    //
                                            author: sacha.profile.name,                                           //
                                            submitted: new Date(now - 3 * 3600 * 1000),                           //
                                            body: 'Bien sûr Tom !'                                                //
                                          });                                                                     //
                                           Posts.insert({                                                         //
                                            post_title: 'Meteor',                                                 //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://meteor.com',                                           //
                                            post_date: new Date(now - 10 * 3600 * 1000)                           //
                                          });                                                                     //
                                            Posts.insert({                                                        //
                                            post_title: 'The Meteor Book',                                        //
                                            post_author: tom._id,                                                 //
                                            author_name: tom.profile.name,                                        //
                                            //url: 'http://themeteorbook.com',                                    //
                                            post_date: new Date(now - 12 * 3600 * 1000)                           //
                                          });*/ /*                                                                //
                                                    var now = new Date().getTime();                               //
                                                                                                                  //
                                                  // Créer deux utilisateurs                                      //
                                                  var tomId = Meteor.users.insert({                               //
                                                    profile: { name: 'Tom Coleman' }                              //
                                                  });                                                             //
                                                  var tom = Meteor.users.findOne(tomId);                          //
                                                  var sachaId = Meteor.users.insert({                             //
                                                    profile: { name: 'Sacha Greif' }                              //
                                                  });                                                             //
                                                  var sacha = Meteor.users.findOne(sachaId);                      //
                                                                                                                  //
                                                  var telescopeId = Posts.insert({                                //
                                                    title: 'Introducing Telescope',                               //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    url: 'http://sachagreif.com/introducing-telescope/',          //
                                                    submitted: new Date(now - 7 * 3600 * 1000),                   //
                                                    commentsCount: 2,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    submitted: new Date(now - 5 * 3600 * 1000),                   //
                                                    body: "C'est un projet intéressant Sacha, est-ce-que je peux y participer ?"
                                                  });                                                             //
                                                                                                                  //
                                                  Comments.insert({                                               //
                                                    postId: telescopeId,                                          //
                                                    userId: sacha._id,                                            //
                                                    author: sacha.profile.name,                                   //
                                                    submitted: new Date(now - 3 * 3600 * 1000),                   //
                                                    body: 'Bien sûr Tom !'                                        //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'Meteor',                                              //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://meteor.com',                                     //
                                                    submitted: new Date(now - 10 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  Posts.insert({                                                  //
                                                    title: 'The Meteor Book',                                     //
                                                    userId: tom._id,                                              //
                                                    author: tom.profile.name,                                     //
                                                    url: 'http://themeteorbook.com',                              //
                                                    submitted: new Date(now - 12 * 3600 * 1000),                  //
                                                    commentsCount: 0,                                             //
                                                    upvoters: [],                                                 //
                                                    votes: 0                                                      //
                                                  });                                                             //
                                                                                                                  //
                                                  for (var i = 0; i < 10; i++) {                                  //
                                                    Posts.insert({                                                //
                                                      title: 'Test post #' + i,                                   //
                                                      author: sacha.profile.name,                                 //
                                                      userId: sacha._id,                                          //
                                                      url: 'http://google.com/?q=test-' + i,                      //
                                                      submitted: new Date(now - i * 3600 * 1000 + 1),             //
                                                      commentsCount: 0,                                           //
                                                      upvoters: [],                                               //
                                                      votes: 0                                                    //
                                                    });                                                           //
                                                  }                                                               //
                                                */                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/items.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("items", function () {                                                                             // 1
  if (Roles.userIsInRole(this.userId, 'paid')) {                                                                  // 2
    return Items.find();                                                                                          // 3
  }                                                                                                               // 4
});                                                                                                               // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publication.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publication.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish('posts', function (options) {                                                                      // 1
  return Posts.find();                                                                                            // 2
});                                                                                                               // 3
Meteor.publish('users', function () {                                                                             // 5
  return Meteors.users.find();                                                                                    // 6
});                                                                                                               // 7
Meteor.publish('comments', function () {                                                                          // 9
  return Comments.find();                                                                                         // 10
});                                                                                                               // 11
Meteor.publish('notifications', function () {                                                                     // 13
  return Notifications.find({                                                                                     // 14
    userId: this.userId,                                                                                          // 14
    read: false                                                                                                   // 14
  });                                                                                                             // 14
});                                                                                                               // 15
Meteor.publish('histoires', function () {                                                                         // 17
  return Histoires.find();                                                                                        // 18
});                                                                                                               // 19
Meteor.publish('requests', function () {                                                                          // 21
  return Requests.find();                                                                                         // 22
});                                                                                                               // 23
Meteor.publish('friends', function () {                                                                           // 25
  return Friends.find();                                                                                          // 26
});                                                                                                               // 27
Meteor.publish('chat', function () {                                                                              // 29
  return Chat.find();                                                                                             // 30
});                                                                                                               // 31
Meteor.publish('userBloquer', function () {                                                                       // 33
  return UserBloquer.find();                                                                                      // 34
});                                                                                                               // 35
Meteor.publish('contact_Chat', function () {                                                                      // 37
  return ContactChat.find();                                                                                      // 38
});                                                                                                               // 39
Meteor.publish("userStatus", function () {                                                                        // 41
  return Meteor.users.find({                                                                                      // 42
    "status.online": true                                                                                         // 42
  });                                                                                                             // 42
});                                                                                                               // 43
Meteor.publish("password", function () {                                                                          // 45
  return Meteor.users.find({                                                                                      // 46
    "services.password.bcrypt": true                                                                              // 46
  });                                                                                                             // 46
});                                                                                                               // 47
Meteor.publish("visites", function () {                                                                           // 50
  return Visites.find();                                                                                          // 51
});                                                                                                               // 52
Meteor.publish('commentaires', function () {                                                                      // 54
  return Commentaires.find();                                                                                     // 55
});                                                                                                               // 56
Meteor.publish('messages_signaler', function () {                                                                 // 58
  return Signaler.find();                                                                                         // 59
});                                                                                                               // 60
Meteor.publish('avertissement_user', function () {                                                                // 62
  return Avertissement.find();                                                                                    // 63
});                                                                                                               // 64
Meteor.publish("userIP", function () {                                                                            // 66
  return Meteor.users.find({}, {                                                                                  // 67
    "status.lastLogin.ipAddr": true                                                                               // 67
  });                                                                                                             // 67
});                                                                                                               // 68
Meteor.publish("lastlogin", function () {                                                                         // 70
  return Meteor.users.find({}, {                                                                                  // 71
    "status.lastLogin.date": true                                                                                 // 71
  });                                                                                                             // 71
});                                                                                                               // 72
Meteor.publish('user_bloquer_IP', function () {                                                                   // 74
  return UserBloquer_IP.find();                                                                                   // 75
});                                                                                                               // 76
Meteor.publish('alertes', function () {                                                                           // 78
  return Alertes.find();                                                                                          // 79
});                                                                                                               // 80
Meteor.publish('delete_alertes', function () {                                                                    // 82
  return DeleteAlertes.find();                                                                                    // 83
});                                                                                                               // 84
Meteor.publish('conseilleres', function () {                                                                      // 86
  return Conseilleres.find();                                                                                     // 87
});                                                                                                               // 88
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.watch(require("meteor/meteor"), {                                                                          // 1
    Meteor: function (v) {                                                                                        // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
Meteor.startup(function () {}); /*Accounts.onCreateUser(function( user) {                                         // 4
                                    /*console.log(user);                                                          //
                                    return user;                                                                  //
                                });*/                                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"mup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// mup.js                                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.exports = {                                                                                                // 1
  servers: {                                                                                                      // 2
    one: {                                                                                                        // 3
      // TODO: set host address, username, and authentication method                                              // 4
      host: '151.80.146.217',                                                                                     // 5
      username: 'root',                                                                                           // 6
      // pem: './path/to/pem'                                                                                     // 7
      password: 'mT9nQ5Pm' // or neither for authenticate from ssh-agent                                          // 8
                                                                                                                  //
    }                                                                                                             // 3
  },                                                                                                              // 2
  app: {                                                                                                          // 13
    // TODO: change app name and path                                                                             // 14
    name: 'kurbys',                                                                                               // 15
    path: '../kurbys',                                                                                            // 16
    servers: {                                                                                                    // 18
      one: {}                                                                                                     // 19
    },                                                                                                            // 18
    buildOptions: {                                                                                               // 22
      serverOnly: true                                                                                            // 23
    },                                                                                                            // 22
    env: {                                                                                                        // 26
      // TODO: Change to your app's url                                                                           // 27
      // If you are using ssl, it needs to start with https://                                                    // 28
      ROOT_URL: 'https://www.kurbys.com',                                                                         // 29
      MONGO_URL: 'mongodb://151.80.146.217:27017/meteor'                                                          // 30
    },                                                                                                            // 26
    ssl: {                                                                                                        // 33
      // (optional)                                                                                               // 33
      // Enables let's encrypt (optional)                                                                         // 34
      autogenerate: {                                                                                             // 35
        email: 'jbroussat@orange.fr',                                                                             // 36
        // comma separated list of domains                                                                        // 37
        domains: 'kurbys.com,www.kurbys.com'                                                                      // 38
      }                                                                                                           // 35
    },                                                                                                            // 33
    docker: {                                                                                                     // 42
      // change to 'kadirahq/meteord' if your app is using Meteor 1.3 or older                                    // 43
      image: 'abernix/meteord:base'                                                                               // 44
    },                                                                                                            // 42
    // Show progress bar while uploading bundle to server                                                         // 47
    // You might need to disable it on CI servers                                                                 // 48
    enableUploadProgressBar: true                                                                                 // 49
  },                                                                                                              // 13
  mongo: {                                                                                                        // 52
    version: '3.4.9',                                                                                             // 53
    servers: {                                                                                                    // 54
      one: {}                                                                                                     // 55
    }                                                                                                             // 54
  }                                                                                                               // 52
};                                                                                                                // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".coffee"
  ]
});
require("./lib/Collections/Chat.js");
require("./lib/Collections/UserBloquer.js");
require("./lib/Collections/alerte.js");
require("./lib/Collections/avertissement.js");
require("./lib/Collections/comment.js");
require("./lib/Collections/commentaires.js");
require("./lib/Collections/conseilleres.js");
require("./lib/Collections/contact_chat.js");
require("./lib/Collections/delete_alerte.js");
require("./lib/Collections/friends.js");
require("./lib/Collections/histoire.js");
require("./lib/Collections/messages_signaler.js");
require("./lib/Collections/notifications.js");
require("./lib/Collections/posts.js");
require("./lib/Collections/request.js");
require("./lib/Collections/user.js");
require("./lib/Collections/userBloquer_IP.js");
require("./lib/Collections/visites.js");
require("./lib/permission.js");
require("./lib/router.js");
require("./server/fixture.js");
require("./server/items.js");
require("./server/publication.js");
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
